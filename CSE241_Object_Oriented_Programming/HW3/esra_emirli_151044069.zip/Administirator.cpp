#include "init.h"
int Administrator::index;
Administrator::Administrator():pid(1),password("gtu1"){ }
Administrator::Administrator(int pidValue,string passwordValue,vector<Lecturer> lValue)
:pid(pidValue),password(passwordValue){
  lecturer=lValue;
}
void Administrator::printTable(){
  if(index == -1){
    for(int i=0;i<Lecturer::allCourses.size();i++){
      for(int j=0;j<Lecturer::allCourses[i].ld.size();j++){
        cout<<"("<<Lecturer::allCourses[i].id<<")"<<Lecturer::allCourses[i].name<<" ";
        switch (Lecturer::allCourses[i].ld[j].day) {
          case 0: cout<<"Mon";
          break;
          case 1: cout<<"Thue";
          break;
          case 2: cout<<"Wed";
          break;
          case 3: cout<<"Thur";
          break;
          case 4: cout<<"Fri";
          break;
        }
        cout<<"_"<<Lecturer::allCourses[i].ld[j].begin<<"-"<<Lecturer::allCourses[i].ld[j].end<<" ";
      }
      if(Lecturer::allCourses[i].ld.size() != 0)
      cout<<endl;
    }
  }
  else{
    //find in allcourses index..
    int j;
    for(j=0;j<Lecturer::allCourses.size();j++){
      if( (Lecturer::allCourses[j].id == index) && Lecturer::allCourses[j].ld.size()!=0 ){
        break;
      }
    }
    index = j;
    for(int j=0;j<Lecturer::allCourses[index].ld.size();j++){
      cout<<"("<<Lecturer::allCourses[index].id<<")"<<Lecturer::allCourses[index].name<<" ";
      switch (Lecturer::allCourses[index].ld[j].day) {
        case 0: cout<<"Mon";
        break;
        case 1: cout<<"Thue";
        break;
        case 2: cout<<"Wed";
        break;
        case 3: cout<<"Thur";
        break;
        case 4: cout<<"Fri";
        break;
      }
      cout<<"_"<<Lecturer::allCourses[index].ld[j].begin<<"-"<<Lecturer::allCourses[index].ld[j].end<<" ";
    }

  }
}
void Administrator::arrangeTimeTable(){
  lecturer_dates tempLD;
  vector<Course> lCourse;
  int check = 0;
  srand (time(NULL));
  if(index == -1){//all courses..
    for(int i=0;i< lecturer.size();i++){
      lCourse = lecturer[i].getCourses();
      for(int j=0; j<lCourse.size();j++){
        while(lCourse[j].available_total_hours > 0){
          check = 0;
          int R1 = rand() % 5 ; //day
          int R2 = rand() % 7 + 9 ; //begin => end(max 17) can be begin + 2 so begin should be until 15..

          //Compare with previous days..
          for(int k=0; k<=j ; k++){
            for(int l=0; l<lCourse[k].ld.size(); l++){
              if(lCourse[k].ld[l].day == R1 &&
                (lCourse[k].ld[l].begin <= R2 && lCourse[k].ld[l].end > R2)){
                  check = 1;
                }
              }
            }
            //Compare with other course..
            if(!check){
              tempLD.day = R1;
              tempLD.begin = R2;
              if(lCourse[j].available_total_hours -2 >= 0)
              tempLD.end = tempLD.begin + 2;
              else
              tempLD.end = tempLD.begin + 1;
              lCourse[j].available_total_hours -= 2;
              lCourse[j].ld.push_back(tempLD);
            }
          }
          Lecturer::allCourses.push_back(lCourse[j]);
        }
      }
    }
    else{ // just this index..
      lCourse = lecturer[index].getCourses();
      for(int j=0; j<lCourse.size();j++){
        while(lCourse[j].available_total_hours > 0){
          check = 0;
          int R1 = rand() % 5 ; //day
          int R2 = rand() % 7 + 9 ; //begin => end(max 17) can be begin + 2 so begin should be until 15..

          //Compare with previous days..
          for(int k=0; k<=j ; k++){
            for(int l=0; l<lCourse[k].ld.size(); l++){
              if(lCourse[k].ld[l].day == R1 &&
                (lCourse[k].ld[l].begin <= R2 && lCourse[k].ld[l].end > R2)){
                  check = 1;
                }
              }
            }
            //Compare with other course..
            if(!check){
              tempLD.day = R1;
              tempLD.begin = R2;
              if(lCourse[j].available_total_hours -2 >= 0)
              tempLD.end = tempLD.begin + 2;
              else
              tempLD.end = tempLD.begin + 1;
              lCourse[j].available_total_hours -= 2;
              lCourse[j].ld.push_back(tempLD);
            }
          }
          Lecturer::allCourses.push_back(lCourse[j]);
        }
      }
    }
