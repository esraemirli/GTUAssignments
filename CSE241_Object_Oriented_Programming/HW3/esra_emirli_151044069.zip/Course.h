#ifndef _Course_H
#define _Course_H

#include "init.h"
struct lecturer_dates{
  int begin,end;
  int day;
};
struct Course{
  int id,code,credit,total_hours,available_total_hours;
  char name[100],field[100];
  vector<lecturer_dates> ld;
  bool isMandatory;
};
struct Field{
  string name;
  int lecturerCount;  // o field'ı veren hoca sayısı..
  vector<int> lecturerId; // o field'ı veren hocanın id'si..
  vector<int> proffField;  // o field'ı veren hocanın toplam prof sayısı..
};

#endif
