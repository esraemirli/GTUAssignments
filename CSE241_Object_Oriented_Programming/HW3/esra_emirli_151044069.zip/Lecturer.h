#ifndef _Lecturer_H
#define _Lecturer_H

#include "init.h"

class Lecturer{
public:
  Lecturer();
  Lecturer(string nameValue,string surnameValue,string titleValue,vector<string> ProfValue,int id);
  int proposeCourse(Course c); /* Lecturer proposes new courses. If courses given by the lecturer is less than
  3, proposed course(s) is added to overall courses list. */
  int assignCourse(Course c,bool isElective);/* Course is assigned to lecturer. If Lecturer gives 3 courses, assignment is not
allowed. If lecturer gives less than 3 courses and s/he has not proposed any elective courses,
program asks her/him to propose an elective course. */
  int getNo() const{
     return personal_id;
   }
   void setproffesions(vector<string> temp);
   vector<string> getProf() const{
     return proffesions;
   }
   vector<string> getProf(){
     return proffesions;
   }
   string getSurname() const{
     return surname;
   }
   static vector<Course> allCourses;
   void clearCourses() {
     courses.clear();
   }
   static void setCourses(vector<Course> c) {
    for(int i=0;i<c.size();i++){
     allCourses.push_back(c[i]);
    }
  }
   vector<Course> getCourses(){
     return courses;
   }

private:
  int personal_id;
  string name,surname,title;
  vector<string> proffesions;
  vector<Course> courses;
};

#endif
