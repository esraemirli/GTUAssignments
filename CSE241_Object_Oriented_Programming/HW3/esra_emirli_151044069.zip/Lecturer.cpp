#include "init.h"
vector<Course> Lecturer::allCourses;

Lecturer::Lecturer(){}
Lecturer::Lecturer(string nameValue,string surnameValue,string titleValue,vector<string> ProfValue,int id)
  :name(nameValue),surname(surnameValue),title(titleValue),personal_id(id)
{
  for(int i=0;i<ProfValue.size();i++){
    proffesions.push_back(ProfValue[i]);
  }
}

int Lecturer::proposeCourse(Course c){

  bool sameField=false;
  for(int i=0;i<proffesions.size();i++){
    if(proffesions[i] == c.field){
      sameField = true;
      break;
    }
  }
  if(!sameField)
    cout<<"Block PROPOSE: field and profession mismatch"<<endl;
  if(courses.size()>=3 || sameField==false)
    return 0;
  else{
    allCourses.push_back(c);
    return 1;
  }
}
int Lecturer::assignCourse(Course c,bool isElective){
  bool sameField=false;
  for(int i=0;i<proffesions.size();i++){
    if(proffesions[i] == c.field){
      sameField = true;
      break;
    }
  }
  if(!sameField)
    cout<<"Block ASSIGN: field and profession mismatch"<<endl;
  if(courses.size()>=3 || sameField==false)
    return 0;
  else{
    c.isMandatory = !isElective;
    courses.push_back(c);
    return 1;
  }
  return 0;
}
