#ifndef _Classroom_H
#define _Classroom_H

#include "init.h"

struct Classroom{
  int id,capacity,student_inroom;
  char c_no[100];
};

#endif
