#include "init.h"
#include <bits/stdc++.h>
FILE* fp;
int findLecturerIndex(vector<Lecturer> l,int id);
vector<string> separate(string const &str, const char mark);
vector<Field> sortingField(vector<Field> f);
int convert(string s);
vector<Lecturer>   MatchFunction(vector<Lecturer> lecturer);
int main(int argc, char const *argv[]) {

  char title[250];
  int i,num,rv;
  vector<Classroom> classroom;
  //Read files and save to structure vector..
  fp = fopen("courses_classrooms.txt","r");
  fscanf(fp,"%s",&title[0]);
  if(strcmp(title,"COURSES")==0){
    i=0;
    while( (rv = fscanf(fp,"%d",&num)) != EOF && rv==1 ){
      Course tempCourse;

      tempCourse.id = num;
      tempCourse.isMandatory = true;
      fscanf(fp,"%s",&tempCourse.name[0]);
      fscanf(fp,"%d",&tempCourse.code);
      fscanf(fp,"%d",&tempCourse.credit);
      fscanf(fp,"%d",&tempCourse.total_hours);
      fscanf(fp,"%s",&tempCourse.field[0]);
      tempCourse.available_total_hours = tempCourse.total_hours;
      Lecturer::allCourses.push_back(tempCourse);
    }

  }
  fscanf(fp,"%s",&title[0]);
  if(strcmp(title,"CLASSROOMS")==0){
    i=0;
    while( (rv = fscanf(fp,"%d",&num)) != EOF && rv==1 ){
      Classroom tempClassroom;
      tempClassroom.id=num;
      fscanf(fp,"%s",&tempClassroom.c_no[0]);
      fscanf(fp,"%d",&tempClassroom.capacity);
      classroom.push_back(tempClassroom);
    }
  }
  fclose(fp);
  vector<Lecturer> lecturer;
  //Read files and save to structure vector..
  fp = fopen("lecturers.txt","r");
  i=0;
  while( (rv = fscanf(fp,"%d",&num)) != EOF && rv==1 ){
    int id;
    char name[100],surname[100],title[100],proffesions[100];
    id = num;
    fscanf(fp,"%s",&name[0]);
    fscanf(fp,"%s",&surname[0]);
    fscanf(fp,"%s",&title[0]);
    fscanf(fp,"%s",&proffesions[0]);
    vector<string> temp;
    temp = separate(proffesions,',');

    lecturer.push_back( Lecturer(name,surname,title,temp,id) );
  }
  fclose(fp);

  //First MATCH lecturer and courses..
  lecturer = MatchFunction(lecturer);
  int assignedCheck,recordCheck;
  vector<string> temp;
  //Create Administrator object and assign pid,password..
  Administrator admin(1,"gtu1",lecturer);
  /***********************  INPUT PART  *******************************/
  string name,surname;
  int no,code,id,level;
  int index;
  string input;
  getline(cin,input);
  temp = separate(input,' '); //seperate schedule part by part days and fields..
  while( temp[0]!="exit"){
    if(temp[0] == "propose"){
      bool lecturerIsExit = false,coursesIsExist = false;
      no=convert(temp[1]);  // convert pid..
      //if lecturer is exits..
      for(int i=0;i<lecturer.size();i++){
        if(lecturer[i].getNo() == no){
          lecturerIsExit = true;
          break;
        }
      }
      if(lecturerIsExit)
        index=findLecturerIndex(lecturer,no);
      else
        cout<<"Error PROPOSE!: no lecture or course"<<endl;
      //if course is exist..
      code=convert(temp[3]);  // string to int
      for(int i=0;i<Lecturer::allCourses.size();i++){
        if(Lecturer::allCourses[i].code == code  ){
          coursesIsExist = true;
          break;
        }
      }
      if(lecturerIsExit && !coursesIsExist){
        Course tempCourse;
        tempCourse.id = Lecturer::allCourses.size() + 1;
        strcpy(tempCourse.name,&temp[2][0]);
        tempCourse.code = convert(temp[3]);
        tempCourse.credit = convert(temp[4]);
        tempCourse.total_hours = convert(temp[5]);
        strcpy(tempCourse.field,&temp[6][0]);
        tempCourse.isMandatory = false;
        recordCheck = lecturer[index].proposeCourse(tempCourse);
      }
      if(recordCheck)
        cout<<"Propose DONE!"<<endl;
      getline(cin,input);
      temp = separate(input,' ');
    }
    else if(temp[0] == "assign"){
      // Asssign lecturer_id course_id
      if(temp.size()==3){
        bool lecturerIsExit = false,coursesIsExist = false;
        no=convert(temp[1]);  // convert pid..
        //if lecturer is exits..
        for(int i=0;i<lecturer.size();i++){
          if(lecturer[i].getNo() == no){
            lecturerIsExit = true;
            break;
          }
        }
        if(lecturerIsExit)
          index=findLecturerIndex(lecturer,no);
        //if course is exist..
        id=convert(temp[2]);  // string to int
        for(int i=0;i<Lecturer::allCourses.size();i++){
          if(Lecturer::allCourses[i].id == id  ){
            coursesIsExist = true;
            break;
          }
        }
        if(!coursesIsExist || !lecturerIsExit)
          cout<<"Error ASSIGN!: no lecture or course"<<endl;
        if(lecturerIsExit && coursesIsExist)
          assignedCheck = lecturer[index].assignCourse(Lecturer::allCourses[id-1],!Lecturer::allCourses[id-1].isMandatory);
        if(assignedCheck)
          cout<<"ASSIGN DONE!"<<endl;
        getline(cin,input);
        temp = separate(input,' ');
      }
      //Assign
      else if(temp.size()==1){
        for(int i=0;i<lecturer.size();i++)
          lecturer[i].clearCourses();
        lecturer = MatchFunction(lecturer);
        getline(cin,input);
        temp = separate(input,' ');
      }
    }
    else if(temp[0] == "timetable"){
      //timetable courses_id
      if(temp.size()==2){
        if(admin.getPid() == 1 && admin.getPassword()=="gtu1" ){
          int count = 0 ;
          //check is exist..
          for(int i=0;i<Lecturer::allCourses.size();i++){
            if(Lecturer::allCourses[i].id == convert(temp[1]) && Lecturer::allCourses[i].ld.size()!= 0 ){
              count++;
              break;
            }
          }
          if(count == 0)
            cout<<"Error TIMETABLE!: no course"<<endl;
          else{
            Administrator::index = convert(temp[1]);
            admin.arrangeTimeTable();
            admin.printTable();
            cout<<"DONE!"<<endl;
          }
        }
      }
      //timetable
      else if(temp.size()==1){
        Administrator::index = -1;
        if(admin.getPid() == 1 && admin.getPassword()=="gtu1" )
          admin.arrangeTimeTable();
        admin.printTable();
      }
      getline(cin,input);
      temp = separate(input,' ');
    }
    /*
    else if(temp[0] == "arrangeC"){
      if(temp.size()==3){

      }
      else if(temp.size()>3){

      }
      else if(temp.size()==1){

      }
      getline(cin,input);
      temp = separate(input,' ');
    } */
    else{
      getline(cin,input);
      temp = separate(input,' ');
    }
  }
  return 0;
}
vector<string> separate(string const &str, const char mark) {
  int start;
  int end = 0;
  vector<string> output;
  //Basic string functions..
  while( (start = str.find_first_not_of(mark, end)) != string::npos){
    end = str.find(mark, start);
    output.push_back(str.substr(start, end - start));
  }
  return output;
}
// string to int..
int convert(string s){
  int id;
  stringstream stoi(s);
  stoi >> id;
  return id;
}
// Find index who has this id..
int findLecturerIndex(vector<Lecturer> l,int id){
  for(int i=0;i<l.size();i++){
    if(l[i].getNo() == id)
    return i;
  }
}
//Sort the total number of proffesions for each field.
vector<Field> sortingField(vector<Field> f){
  for(int i=0;i<f.size();i++){
    for(int j=i;j<f.size();j++){
      if(f[i].lecturerCount > f[j].lecturerCount ){
        Field tempField = f[i];
        f[i] = f[j];
        f[j] = tempField;
      }
    }
  }
  return f;
}
// MATCH Lecturer and Courses...
vector<Lecturer> MatchFunction(vector<Lecturer> lecturer){
  vector<Field> fieldVector;
  int count;
  //push different field..
  for(int i=0;i<Lecturer::allCourses.size();i++){
    count=0;
    Field TempFieldVector;
    if(fieldVector.size()==0)
        TempFieldVector.name = Lecturer::allCourses[i].field;
    for(int j=0;j<fieldVector.size();j++){
      if( Lecturer::allCourses[i].field == fieldVector[j].name )
          count++;
    }
    if(count==0){  //daha önce bu ders yoktur.. kaydet..
      TempFieldVector.name = Lecturer::allCourses[i].field;
      fieldVector.push_back(TempFieldVector);
    }
  }

  // FILL FIELD STRUCTURE..
  vector<string> temp;
  for(int i=0 ; i<fieldVector.size() ; i++){
    fieldVector[i].lecturerCount = 0;
    for(int j=0; j<lecturer.size() ;j++ ){
      temp = lecturer[j].getProf();
      for(int k=0;k<temp.size();k++ ){
        if(fieldVector[i].name == temp[k]){
          fieldVector[i].lecturerCount ++;
          fieldVector[i].lecturerId.push_back(lecturer[j].getNo());
          fieldVector[i].proffField.push_back(temp.size());
        }
      }
    }
  }

  int assignedCheck,recordCheck;
  fieldVector = sortingField(fieldVector);

  for(int i=0; i<fieldVector.size(); i++){
    assignedCheck = 0;
    for(int j=0; j<Lecturer::allCourses.size(); j++){
      if(fieldVector[i].name == Lecturer::allCourses[j].field){
        for(int k=0; k < fieldVector[i].lecturerId.size() && assignedCheck == 0;k++ ){
          assignedCheck = lecturer[fieldVector[i].lecturerId[k]-1].assignCourse(Lecturer::allCourses[j],!Lecturer::allCourses[j].isMandatory);
        }
        assignedCheck = 0;
      }
    }
  }
  return lecturer;
}
