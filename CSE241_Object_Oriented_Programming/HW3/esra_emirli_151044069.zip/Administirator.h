#ifndef _Administrator_H
#define _Administrator_H

#include "init.h"

class Administrator{
public:
  Administrator();
  Administrator(int,string,vector<Lecturer>);
  void arrangeClassroom(); //determine which course is processed which classrooms. It pays regard to timetable of courses.
  void arrangeTimeTable(); //determine lecture dates of each courses.
  int getPid() const{ return pid;}
  string getPassword() const{ return password; }
  void printTable();
  static int index;
private:
  vector<Lecturer> lecturer;
  Classroom classroom;
  int pid;
  string password;
};

#endif
