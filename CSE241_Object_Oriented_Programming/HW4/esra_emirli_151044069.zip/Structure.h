#ifndef _Structure_H
#define _Structure_H

#include "init.h"

struct lecturer_dates{
  int begin,end;
  int day;
};
struct Course{
  int id,code,credit,total_hours,available_total_hours;
  char name[100],field[100];
  vector<lecturer_dates> ld;
  bool isMandatory;
  vector<int>listOfStudent;
};

struct Field{
  string name;
  int lecturerCount;  //  number of lecturer who gives this course..
  vector<int> lecturerId;  //number of lecturer id who gives this course..
  vector<int> proffField; //number of lecturer proffesions number who gives this course..
};
#endif
