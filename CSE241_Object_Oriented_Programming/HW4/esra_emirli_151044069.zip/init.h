#include "Administrator.h"
#include "Lecturer.h"
#include "Structure.h"
#include "Classroom.h"
#include "Student.h"

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <sstream>
#include <ctime>
using namespace std;
