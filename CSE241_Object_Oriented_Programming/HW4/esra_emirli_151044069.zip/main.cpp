#include "init.h"
using LecturerNS::Lecturer;
using ClassroomNS::Classroom;
using AdministratorNS::Administrator;
using StudentNS::Student;

vector<Field> sortingField(vector<Field>);
int findLecturerIndex(vector<Lecturer>,int );
vector<string> separate(string const &str, const char mark);
int convert(string s);
vector<Lecturer> MatchFunction(vector<Lecturer> lecturer);
bool isExist(vector<Student> s,int id);
int countStudent(int CourseId,int StudentId);

FILE* fp;
int main(int argc, char const *argv[]) {
  char title[250];
  int i,num,rv;
  vector<Classroom> classroom;
  //Read files and save to structure vector..
  fp = fopen("courses_classrooms.txt","r");
  fscanf(fp,"%s",&title[0]);
  if(strcmp(title,"COURSES")==0){
    i=0;
    while( (rv = fscanf(fp,"%d",&num)) != EOF && rv==1 ){
      Course tempCourse;
      tempCourse.id = num;
      tempCourse.isMandatory = true;
      fscanf(fp,"%s",&tempCourse.name[0]);
      fscanf(fp,"%d",&tempCourse.code);
      fscanf(fp,"%d",&tempCourse.credit);
      fscanf(fp,"%d",&tempCourse.total_hours);
      fscanf(fp,"%s",&tempCourse.field[0]);
      tempCourse.available_total_hours = tempCourse.total_hours;
      Lecturer::allCourses.push_back(tempCourse);
    }
  }
  fscanf(fp,"%s",&title[0]);
  if(strcmp(title,"CLASSROOMS")==0){
    i=0;
    while( (rv = fscanf(fp,"%d",&num)) != EOF && rv==1 ){
      int capacity;
      char className[100];
      fscanf(fp,"%s",&className[0]);
      fscanf(fp,"%d",&capacity);
      //set values..
      Classroom tempClassroom;
      tempClassroom.setID(num);
      tempClassroom.setClassName(className);
      tempClassroom.setCapacity(capacity);
      classroom.push_back(tempClassroom);
    }
  }
  fclose(fp);
  vector<Lecturer> lecturer;
  //Read files and save to structure vector..
  fp = fopen("lecturers.txt","r");
  i=0;
  while( (rv = fscanf(fp,"%d",&num)) != EOF && rv==1 ){
    int id;
    char name[100],surname[100],title[100],proffesions[100];
    id = num;
    fscanf(fp,"%s",&name[0]);
    fscanf(fp,"%s",&surname[0]);
    fscanf(fp,"%s",&title[0]);
    fscanf(fp,"%s",&proffesions[0]);
    vector<string> temp;
    temp = separate(proffesions,',');
    //set values..
    Lecturer tempLecturer;
    tempLecturer.setID(num);
    tempLecturer.setName(name,surname);
    tempLecturer.setTitle(title);
    tempLecturer.setProff(temp);
    lecturer.push_back(tempLecturer);
  }
  fclose(fp);
  //First MATCH lecturer and courses..
  lecturer = MatchFunction(lecturer);
  /*  ******************* INPUT PART *********************** */
  //Create Administrator object and assign pid,password..
  Administrator admin(1,"gtu1",lecturer,classroom);
  vector<Student> student;

  int assignedCheck,recordCheck;
  string name,surname;
  int no,code,id,level;
  int index;

  string input;
  getline(cin,input);

  vector<string> temp;
  temp = separate(input,' '); //seperate schedule part by part days and fields..
  while( temp[0]!="exit"){
    //Enter student info and check all situation..
    if(temp[0] == "-ns"){
      no=convert(temp[3]);  //convert to int
      level=convert(temp[4]);
      name= temp[1];
      surname =temp[2];
      if(!isExist(student,no) && (level<5 && level>0))
       student.push_back( Student(name,surname,no,level) );
      else
       cerr<<"BLOCK! Check INFO!"<<endl;
      getline(cin,input);
      temp = separate(input,' ');
    }
    else if(temp[0] == "propose"){
      bool lecturerIsExit = false,coursesIsExist = false;
      no=convert(temp[1]);  // convert pid..
      //if lecturer is exits..
      for(int i=0;i<lecturer.size();i++){
        if(lecturer[i].getID() == no){
          lecturerIsExit = true;
          break;
        }
      }
      if(lecturerIsExit)
      index=findLecturerIndex(lecturer,no);
      else
      cerr<<"Error PROPOSE!: no lecture or course"<<endl;
      //if course is exist..
      code=convert(temp[3]);  // string to int
      for(int i=0;i<Lecturer::allCourses.size();i++){
        if(Lecturer::allCourses[i].code == code  ){
          coursesIsExist = true;
          break;
        }
      }
      if(lecturerIsExit && !coursesIsExist){
        Course tempCourse;
        tempCourse.id = Lecturer::allCourses.size() + 1;
        strcpy(tempCourse.name,&temp[2][0]);
        tempCourse.code = convert(temp[3]);
        tempCourse.credit = convert(temp[4]);
        tempCourse.total_hours = convert(temp[5]);
        strcpy(tempCourse.field,&temp[6][0]);
        tempCourse.isMandatory = false;
        recordCheck = lecturer[index].proposeCourse(tempCourse);
      }
      if(recordCheck)
      cout<<"Propose DONE!"<<endl;
      getline(cin,input);
      temp = separate(input,' ');
    }
    else if(temp[0] == "assign"){
      // Asssign lecturer_id course_id
      if(temp.size()==3){
        bool lecturerIsExit = false,coursesIsExist = false;
        no=convert(temp[1]);  // convert pid..
        //if lecturer is exits..
        for(int i=0;i<lecturer.size();i++){
          if(lecturer[i].getID() == no){
            lecturerIsExit = true;
            break;
          }
        }
        if(lecturerIsExit)
        index=findLecturerIndex(lecturer,no);
        //if course is exist..
        id=convert(temp[2]);  // string to int
        for(int i=0;i<Lecturer::allCourses.size();i++){
          if(Lecturer::allCourses[i].id == id  ){
            coursesIsExist = true;
            break;
          }
        }
        if(!coursesIsExist || !lecturerIsExit)
        cerr<<"Error ASSIGN!: no lecture or course"<<endl;
        if(lecturerIsExit && coursesIsExist)
        assignedCheck = lecturer[index].assignCourse(Lecturer::allCourses[id-1],!Lecturer::allCourses[id-1].isMandatory);
        if(assignedCheck)
        cout<<"ASSIGN DONE!"<<endl;
        getline(cin,input);
        temp = separate(input,' ');
      }
      //Assign
      else if(temp.size()==1){
        for(int i=0;i<lecturer.size();i++)
        lecturer[i].clearCourses();
        lecturer = MatchFunction(lecturer);
        getline(cin,input);
        temp = separate(input,' ');
      }
      cout<<"********** ALLCOURSES ************"<<endl;
      for(int j=0;j<Lecturer::allCourses.size();j++)
      cout<<"--"<<Lecturer::allCourses[j].id<<" "<<Lecturer::allCourses[j].name<<endl;
      for(int i=0;i<lecturer.size();i++)
        lecturer[i].print();
    }
    else if(temp[0] == "timetable"){
      //timetable courses_id
      if(temp.size()==2){
        if(admin.getPid() == 1 && admin.getPassword()=="gtu1" ){
          int count = 0 ;
          //check is exist..
          for(int i=0;i<Lecturer::allCourses.size();i++){
            if(Lecturer::allCourses[convert(temp[1])-1].id == convert(temp[1]) ){ //ld.size()!=0  is means hour of couse is known !!
              count++;
              break;
            }
          }
          if(count == 0)
            cerr<<"Error TIMETABLE!: no course"<<endl;
          else{
            Administrator::index = convert(temp[1]);  //index of that course..
            admin.arrangeTimeTable();
            // admin.printTable();
            cout<<"DONE!"<<endl;
          }
        }
      }
      //timetable
      else if(temp.size()==1){
        Administrator::index = -1;
        if(admin.getPid() == 1 && admin.getPassword()=="gtu1" )
          admin.arrangeTimeTable();
          admin.printTable();
      }
      getline(cin,input);
      temp = separate(input,' ');
    }
    else if(temp[0] == "arrangeC"){
      //arrangeC
      if(temp.size()==1){
        if(admin.getPid() == 1 && admin.getPassword()=="gtu1" ) ;
          admin.arrangeClassroom();
          classroom = admin.getClassroom();
      }
      getline(cin,input);
      temp = separate(input,' ');
    }
    else if(temp[0] == "enter"){
      //enter student_no class_no hourOfWeek
      int student_no,class_no,hourOfWeek;
      bool classExist=false;
      student_no=convert(temp[1]);  //convert to int
      class_no=convert(temp[2]);
      hourOfWeek=convert(temp[3]);
      //class is exist check..
      for(int i=0;i<classroom.size();i++){
        if(classroom[i].getID() == class_no){
          classExist=true;
          break;
        }
      }
      // Student and class is exist or not..
      if(isExist(student,student_no) && classExist){
        // Check lesson is exist at that time or not and student in orther class..
        if(!admin.checkLecture(class_no,hourOfWeek) || student[student_no].getLectureStatus() == 1)
          cerr<<"BLOCK! Class have not any lesson or Student in other class!"<<endl;
        else{
          int CourseID=classroom[class_no-1].EnterClassroom(student_no,hourOfWeek);
          if( CourseID!=-1){
            student[student_no].setLectureStatus(1); //record is success..
            Lecturer::allCourses[CourseID-1].listOfStudent.push_back(student_no); //??
          }
        }
      }
      else
        cerr<<"BLOCK!Cannot fount student or class!"<<endl;
      getline(cin,input);
      temp = separate(input,' ');
    }
    else if(temp[0] == "quit"){
      //enter student_no class_no hourOfWeek
      int student_no;
      int classroomNo = -1;
      student_no=convert(temp[1]);  //convert to int
      // Student and class is exist or not..
      if(isExist(student,student_no) ){
        // Check lesson is exist at that time or not and student in orther class..
        if(student[student_no].getLectureStatus() == 0)
          cerr<<"Student is not enroll this lesson!"<<endl;
        else{
          for(int i=0;i<classroom.size();i++){
            if(classroom[i].checkStudent(student_no)){
                classroomNo = i;
                break;
            }
          }
          int numStudent=classroom[classroomNo].QuitClassroom(student_no);
          if(classroomNo!=-1 && numStudent!=-1){
            student[student_no].setLectureStatus(0); //quit is success.
            cout<<"Student inroom: "<<numStudent<<endl;
          }
        }
      }
      else
        cerr<<"BLOCK! Student cannot found!"<<endl;
      getline(cin,input);
      temp = separate(input,' ');
    }
    else if(temp[0] == "attandance"){
      //attendance [course_id]
      int CourseID=convert(temp[1]);  //convert to int
      bool isExist = false;
      // Check course is exist..
      for(int i=0;i<Lecturer::allCourses.size();i++){
        if(Lecturer::allCourses[i].id == CourseID){
          isExist =true;
          break;
        }
      }
      if(isExist ){
        vector<int> counted; //Don't count again and again same student..
        bool _counted=false;
        int count;
        for(int j=0;j<Lecturer::allCourses[CourseID-1].listOfStudent.size();j++){
          for(int k=0;k<counted.size();k++){
            // This student is counted..
            if(counted[k] == Lecturer::allCourses[CourseID-1].listOfStudent[j]){
              _counted = true;
              break;
            }
          }
          if(!_counted){
            count = countStudent(CourseID-1,Lecturer::allCourses[CourseID-1].listOfStudent[j]);
            counted.push_back(Lecturer::allCourses[CourseID-1].listOfStudent[j]);
          }
          // Find the student name using by its id..
          // cout<<Lecturer::allCourses[CourseID-1].name<<"~";  course name..
          for(int l=0;l<student.size();l++){
            if(student[l].getNo() == Lecturer::allCourses[CourseID-1].listOfStudent[j])
              cout<<student[l].getName()<<" ";
          }
          cout<<count<<" - ";
        }
      }
      else
        cerr<<"BLOCK! Course cannot found!"<<endl;
      getline(cin,input);
      temp = separate(input,' ');
    }
    else{
      getline(cin,input);
      temp = separate(input,' ');
    }
  }

  return 0;
}
// MATCH Lecturer and Courses...
vector<Lecturer> MatchFunction(vector<Lecturer> lecturer){
  vector<Field> fieldVector;
  int count;
  //push different field..
  for(int i=0;i<Lecturer::allCourses.size();i++){
    count=0;
    Field TempFieldVector;
    if(fieldVector.size()==0)
    TempFieldVector.name = Lecturer::allCourses[i].field;
    for(int j=0;j<fieldVector.size();j++){
      if( Lecturer::allCourses[i].field == fieldVector[j].name )
      count++;
    }
    if(count==0){  //this lesson din't push yet..
      TempFieldVector.name = Lecturer::allCourses[i].field;
      fieldVector.push_back(TempFieldVector);
    }
  }


  // FILL FIELD STRUCTURE..
  vector<string> temp;
  for(int i=0 ; i<fieldVector.size() ; i++){
    fieldVector[i].lecturerCount = 0;
    for(int j=0; j<lecturer.size() ;j++ ){
      temp = lecturer[j].getProff();
      for(int k=0;k<temp.size();k++ ){
        if(fieldVector[i].name == temp[k]){
          fieldVector[i].lecturerCount ++;
          fieldVector[i].lecturerId.push_back(lecturer[j].getID());
          fieldVector[i].proffField.push_back(temp.size());
        }
      }
    }
  }

  int assignedCheck,recordCheck;
  fieldVector = sortingField(fieldVector);

  for(int i=0; i<fieldVector.size(); i++){
    assignedCheck = 0;
    for(int j=0; j<Lecturer::allCourses.size(); j++){
      if(fieldVector[i].name == Lecturer::allCourses[j].field){
        for(int k=0; k < fieldVector[i].lecturerId.size() && assignedCheck == 0;k++ ){
          assignedCheck = lecturer[fieldVector[i].lecturerId[k]-1].assignCourse(Lecturer::allCourses[j],!Lecturer::allCourses[j].isMandatory);
        }
        assignedCheck = 0;
      }
    }
  }
  return lecturer;
}
int countStudent(int CourseId,int StudentId){
  int count = 0;
  for(int i=0;i<Lecturer::allCourses[CourseId].listOfStudent.size();i++){
    if(Lecturer::allCourses[CourseId].listOfStudent[i] == StudentId){
      count++;
    }
  }
  return count;
}
//Sort the total number of proffesions for each field.
vector<Field> sortingField(vector<Field> f){
  for(int i=0;i<f.size();i++){
    for(int j=i;j<f.size();j++){
      if(f[i].lecturerCount > f[j].lecturerCount ){
        Field tempField = f[i];
        f[i] = f[j];
        f[j] = tempField;
      }
    }
  }
  return f;
}
vector<string> separate(string const &str, const char mark) {
  int start;
  int end = 0;
  vector<string> output;
  //Basic string functions..
  while( (start = str.find_first_not_of(mark, end)) != string::npos){
    end = str.find(mark, start);
    output.push_back(str.substr(start, end - start));
  }
  return output;
}
// string to int..
int convert(string s){
  int id;
  stringstream stoi(s);
  stoi >> id;
  return id;
}
// Find index who has this id..
int findLecturerIndex(vector<Lecturer> l,int id){
  for(int i=0;i<l.size();i++){
    if(l[i].getID() == id)
    return i;
  }
}
//Check the person is student in school or not..
bool isExist(vector<Student> s,int id){
  for(int i=0;i<s.size();i++){
    if(s[i].getNo() == id)
    return true;
  }
  return false;
}
