#ifndef _Student_H
#define _Student_H
#include "init.h"
namespace StudentNS{
  class Student{
  public:
    Student();
    Student(string nameValue,string surnameValue,int number,int levelValue);
    Student(const Student& admin); //Copy Constructor
    void operator=(const Student& admin); //Assignment Operator
    ~Student();
    void output();
    void setLectureStatus(int status){
      if(status == 0)
        lectureStatus = 0;
      else if(status == 1)
        lectureStatus = 1;
    }

    int getLectureStatus(){
      return lectureStatus;
    }
    int getNo() const{
      return student_no;
    }
    string getName() const{
      return name;
    }
  private:
    int lectureStatus;
    string name,surname;
    int student_no,level;
    int max_credit;
    int using_credit;
  };
}
#endif
