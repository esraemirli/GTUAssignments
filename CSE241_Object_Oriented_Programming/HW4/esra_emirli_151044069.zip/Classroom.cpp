#include "init.h"
namespace ClassroomNS{
  Classroom::Classroom() :id(0),capacity(0),student_inroom(0),attandanceRecord(NULL){
    int hourOfClass=40; //8*5
    attandanceRecord = new int*[hourOfClass];
    for(int i = 0; i < hourOfClass; ++i)
     attandanceRecord[i] = new int[capacity];

    for(int i = 0; i < hourOfClass; ++i)
      attandanceRecord[i][0] = -1;
  }
  Classroom::Classroom(char* nameValue,int idValue,int capacityValue)
    :id(idValue),capacity(capacityValue) {
    Classroom();
    strcpy(c_no,nameValue);
  }
  /* ********************** BIG TREE  ****************************************** */
  // COPY CONSTRUCTOR..
  // Classroom::Classroom(const Classroom& _class){
  //   id=_class.id;
  //   student_inroom = _class.student_inroom;
  //   strcpy(c_no, _class.c_no);
  //   //DEEP COPY...
  //   capacity = _class.capacity;
  //   if(this != &_class){
  //     int hourOfClass=40; //8*5
  //     attandanceRecord = new int*[hourOfClass];
  //     for(int i = 0; i < hourOfClass; ++i)
  //      attandanceRecord[i] = new int[capacity];
  //
  //      for(int i=0;i<40;i++){
  //        for(int j=0;j<capacity;j++)
  //           attandanceRecord[i][j] = _class.attandanceRecord[i][j];
  //      }
  //   }
  // }

  // Classroom::~Classroom(){
  //   if(attandanceRecord!=NULL){
  //     for(int i=0;i<40;i++)
  //       delete [] attandanceRecord[i];
  //     delete []  attandanceRecord;
  //   }
  // }

  // void Classroom::operator=(const Classroom& _class){
  //   id=_class.id;
  //   student_inroom = _class.student_inroom;
  //   strcpy(c_no, _class.c_no);
  //   capacity = _class.capacity;
  // }

  /* ************************************************************************ */
  void Classroom::setClassName(const char* no){
    strcpy(c_no,no);
  }
  void Classroom::setID(const int idValue){
    id=idValue;
  }
  void Classroom::setCapacity(const int capacityValue){
    capacity = capacityValue;
  }
  string Classroom::getName() const{
    return c_no;
  }
  int Classroom::EnterClassroom(int studentId,int hour){
    if(student_inroom == capacity)
      return -1;
    for(int i=0; i<capacity; i++){

      if(attandanceRecord[hour][i] == -1){

        attandanceRecord[hour][i] = studentId;
        if(i < capacity-1)
          attandanceRecord[hour][i+1] = -1;
        // o saatte hangi kurs varsa onun idsini döndür..
        student_inroom++;
        cout<<"Student inroom: "<<student_inroom<<endl;
        for(int j=0;j<fR.size();j++){
          if(fR[j].day == hour/8 && ( (hour%8 +8 )>=fR[j].begin && (hour%8 +8 )<fR[j].end  ) )
            return fR[j].CourseID;
        }
      }
    }
    return -1;
  }
  int Classroom::checkStudent(int studentId){
    for(int i=0;i<40;i++){
      for(int j=0;j<capacity;j++){
        if(attandanceRecord[i][j] == studentId)
          return 1;
      }
    }
    return 0;
  }

  int Classroom::QuitClassroom(int studentId){
    if(student_inroom == 0)
      return -1;
    student_inroom--;
    return student_inroom;
  }
  int Classroom::getID() const{
    return id;
  }
} //end of Classroom name
