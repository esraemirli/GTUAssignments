#include "init.h"
namespace StudentNS{
  Student::Student() : name(NULL),surname(NULL),student_no(0),level(0),lectureStatus(0){ }
  Student::Student(string nameValue,string surnameValue,int number,int levelValue)
  : name(nameValue),surname(surnameValue),student_no(number),level(levelValue),lectureStatus(0){
    using_credit= 0;
    if(level==1)
      max_credit = 20;
    else if(level==2)
      max_credit= 21;
    else if(level==3)
      max_credit= 22;
    else
      max_credit= 23;
  }
  // Copy Constructor...
  Student::Student(const Student& s){
    lectureStatus = s.lectureStatus;
    name = s.name;
    surname = s.surname;
    student_no = s.student_no;
    level = s.level;
    max_credit = s.max_credit;
    using_credit = s.using_credit;
  }
  //Assignment Operator...
  void Student::operator=(const Student& s){
    lectureStatus = s.lectureStatus;
    name = s.name;
    surname = s.surname;
    student_no = s.student_no;
    level = s.level;
    max_credit = s.max_credit;
    using_credit = s.using_credit;
  }
  Student::~Student(){
    // No dynamic element...
  }
  void Student::output(){
    cout<<name<<" "<<surname<<"--"<<student_no<<endl;
  }
}
