#ifndef _Administrator_H
#define _Administrator_H

#include "init.h"
using LecturerNS::Lecturer;
using ClassroomNS::Classroom;
namespace AdministratorNS{
  class Administrator{
  public:
    Administrator();
    Administrator(int,string,vector<Lecturer>&,vector<Classroom>&);
    Administrator(const Administrator& admin); //Copy Constructor
    void operator=(const Administrator& admin); //Assignment Operator
    ~Administrator();
    void arrangeClassroom(); //determine which course is processed which classrooms. It pays regard to timetable of courses.
    void arrangeTimeTable(); //determine lecture dates of each courses.
    int getPid() const{ return pid;}
    string getPassword() const{ return password; }
    void printTable();
    static int index;
    const vector<Classroom> getClassroom() const{ return classroom;}
    int checkLecture(int,int);
  private:
    vector<Lecturer> lecturer;
    vector<Classroom> classroom;
    int pid;
    string password;
  };
}

#endif
