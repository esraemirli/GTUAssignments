#ifndef _Lecturer_H
#define _Lecturer_H

#include "init.h"
using ClassroomNS::Classroom;
namespace LecturerNS{
  class Lecturer{
  public:
    Lecturer();
    //Lecturer( const Lecturer& LecturerObject); //copy constructor..
    Lecturer(string nameValue,string surnameValue,string titleValue,vector<string> ProfValue,int id);
    Lecturer(const Lecturer& admin); //Copy Constructor
    void operator=(const Lecturer& admin); //Assignment Operator
    ~Lecturer();
    int proposeCourse(Course c);
    int assignCourse(Course c,bool isElective);
    void setName(const string nameValue,const string surnameValue);
    void setID(const int idValue);
    void setTitle(const string titleValue);
    void setProff(const vector<string> ProffValue);
    int getID() const;
    string getSurname() const;
    void setproffesions(vector<string> temp);
    vector<string> getProff();
    void clearCourses() {
      courses.clear();
    }
    static void setCourses(vector<Course> c) {
      for(int i=0;i<c.size();i++){
        allCourses.push_back(c[i]);
      }
    }
    vector<Course> getCourses(){
      return courses;
    }
    void print() const;
    static vector<Course> allCourses;
  private:
    int personal_id;
    string name,surname,title;
    vector<string> proffesions;
    vector<Course> courses;
  };
} //end of Lecturer NameSpace

#endif
