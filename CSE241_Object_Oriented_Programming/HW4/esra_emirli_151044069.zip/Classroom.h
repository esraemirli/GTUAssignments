#ifndef _Classroom_H
#define _Classroom_H

#include "init.h"
namespace ClassroomNS{
  struct FullRoom{
    int begin;
    int end;
    int day;
    int CourseID; // o saat hangi ders var?
    vector<string> className;
  };
  class Classroom{
  public:
    Classroom();
    Classroom(char* nameValue,int idValue,int capacityValue);
  /*  Classroom(const Classroom& _class);
    void operator=(const Classroom& _class);
    ~Classroom(); */
    int EnterClassroom(int,int);
    int QuitClassroom(int);
    void setClassName(const char* no);
    void setID(const int idValue);
    void setCapacity(const int capacityValue);
    string getName() const;
    int getID() const;
    int checkStudent(int);
    vector<FullRoom> fR;
    int checkLecture(int);
  private:

    int id,capacity,student_inroom;
    char c_no[100];
    int **attandanceRecord;
  };
}

#endif
