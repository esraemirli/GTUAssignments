#include "init.h"
namespace LecturerNS{
  vector<Course> Lecturer::allCourses;
  Lecturer::Lecturer(){}
  Lecturer::Lecturer(string nameValue,string surnameValue,string titleValue,vector<string> ProfValue,int id)
    :name(nameValue),surname(surnameValue),title(titleValue),personal_id(id),proffesions(ProfValue)
  {  }
  // Copy Constructor...
  Lecturer::Lecturer(const Lecturer& l){
    personal_id = l.personal_id;
    name = l.name;
    surname = l.surname;
    title = l.title;
    proffesions = l.proffesions;
    courses = l.courses;
  }
  //Assignment Operator...
  void Lecturer::operator=(const Lecturer& l){
    personal_id = l.personal_id;
    name = l.name;
    surname = l.surname;
    title = l.title;
    proffesions = l.proffesions;
    courses = l.courses;
  }
  Lecturer::~Lecturer(){
    // No dynamic element...
  }
  void Lecturer::print() const{
    cout<<name<<" "<<surname<<endl;
    for(int j=0;j<courses.size();j++)
    cout<<"--"<<courses[j].name<<" ";
    cout<<endl;
  }
  int Lecturer::getID() const{
    return personal_id;
  }
  string Lecturer::getSurname() const{
    return surname;
  }
  vector<string> Lecturer::getProff(){
    return proffesions;
  }
  void Lecturer::setName(const string nameValue,const string surnameValue) {
    name = nameValue;
    surname= surnameValue;
  }
  void Lecturer::setID(const int idValue){
    personal_id = idValue ;
  }
  void Lecturer::setTitle(const string titleValue){
    title = titleValue;
  }
  void Lecturer::setProff(const vector<string> ProffValue){
    for(int i=0;i<ProffValue.size();i++){
      proffesions.push_back(ProffValue[i]);
    }
  }

  int Lecturer::proposeCourse(Course c){

    bool sameField=false;
    for(int i=0;i<proffesions.size();i++){
      if(proffesions[i] == c.field){
        sameField = true;
        break;
      }
    }
    if(!sameField)
      cout<<"Block PROPOSE: field and profession mismatch"<<endl;
    if(courses.size()>=3 || sameField==false)
      return 0;
    else{
      allCourses.push_back(c);
      return 1;
    }
  }
  int Lecturer::assignCourse(Course c,bool isElective){
    bool sameField=false;
    for(int i=0;i<proffesions.size();i++){
      if(proffesions[i] == c.field){
        sameField = true;
        break;
      }
    }
    if(!sameField)
      cout<<"Block ASSIGN: field and profession mismatch"<<endl;
    if(courses.size()>=3 || sameField==false)
      return 0;
    else{
      c.isMandatory = !isElective;
      courses.push_back(c);
      return 1;
    }
    return 0;
  }

}//end of NameSpace
