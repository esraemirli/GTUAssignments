#include "init.h"
using LecturerNS::Lecturer;
using ClassroomNS::Classroom;
using ClassroomNS::FullRoom;

namespace AdministratorNS{
  int Administrator::index;
  Administrator::Administrator():pid(1),password("gtu1"){  }
  Administrator::Administrator(int pidValue,string passwordValue,vector<Lecturer>& lValue,vector<Classroom>& cValue)
  :pid(pidValue),password(passwordValue){
    lecturer=lValue;
    classroom=cValue;
  }
  // Copy Constructor...
  Administrator::Administrator(const Administrator& admin){
    pid = admin.pid;
    password = admin.password;
    lecturer = admin.lecturer;
    classroom = admin.classroom;
  }
  //Assignment Operator...
  void Administrator::operator=(const Administrator& admin){
    lecturer = admin.lecturer;
    classroom = admin.classroom;
    pid = admin.pid;
    password = admin.password;
  }
  Administrator::~Administrator(){
    // No dynamic element...
  }
  void Administrator::printTable(){
    if(index == -1){
      for(int i=0;i<Lecturer::allCourses.size();i++){
        for(int j=0;j<Lecturer::allCourses[i].ld.size();j++){
          cout<<"("<<Lecturer::allCourses[i].id<<")"<<Lecturer::allCourses[i].name<<" ";
          switch (Lecturer::allCourses[i].ld[j].day) {
            case 0: cout<<"Mon";
            break;
            case 1: cout<<"Thue";
            break;
            case 2: cout<<"Wed";
            break;
            case 3: cout<<"Thur";
            break;
            case 4: cout<<"Fri";
            break;
          }
          cout<<"_"<<Lecturer::allCourses[i].ld[j].begin<<"-"<<Lecturer::allCourses[i].ld[j].end<<" ";
        }
        cout<<endl;
      }
    }
    else{
      //find in allcourses index..
      int j;
      for(j=0;j<Lecturer::allCourses.size();j++){
        if( Lecturer::allCourses[j].id == index ){
          break;
        }
      }
      index = j;
      for(int j=0;j<Lecturer::allCourses[index].ld.size();j++){
        cout<<"("<<Lecturer::allCourses[index].id<<")"<<Lecturer::allCourses[index].name<<" ";
        switch (Lecturer::allCourses[index].ld[j].day) {
          case 0: cout<<"Mon";
          break;
          case 1: cout<<"Thue";
          break;
          case 2: cout<<"Wed";
          break;
          case 3: cout<<"Thur";
          break;
          case 4: cout<<"Fri";
          break;
        }
        cout<<"_"<<Lecturer::allCourses[index].ld[j].begin<<"-"<<Lecturer::allCourses[index].ld[j].end<<" ";
      }

    }
  }
  void Administrator::arrangeTimeTable(){
    int a;
    lecturer_dates tempLD;
    int check = 0;
    srand (time(NULL));
    if(index == -1){ //all courses..
      vector<Course> lCourse;
      for(int i=0;i< lecturer.size();i++){
        lCourse = lecturer[i].getCourses(); // i=0 -> MALWARE NETWORK MATHEMATICS
        //find course index in allCourses to check available_total_hours..
        for(int j=0; j<lCourse.size();j++){
          for(a=0;a<Lecturer::allCourses.size();a++){
            if(Lecturer::allCourses[a].id == lCourse[j].id)
              break;
          }
          int n=0;
          while(Lecturer::allCourses[a].available_total_hours > 0 ){
            check = 0;
            int R1 = rand() % 5 ; //day
            int R2 = rand() % 7 + 9 ; //begin => end(max 17) can be begin + 2 so begin should be until 15..

            //Compare with previous days..
            for(int k=0; k<=j ; k++){
              for(int l=0; l<lCourse[k].ld.size(); l++){
                if(lCourse[k].ld[l].day == R1 && (lCourse[k].ld[l].begin <= R2 && lCourse[k].ld[l].end > R2) ){
                    check = 1;
                }
              }
            }
            //Compare with other course..
            if(!check){
              tempLD.day = R1;
              tempLD.begin = R2;
              if(lCourse[j].available_total_hours -2 >= 0)
                tempLD.end = tempLD.begin + 2;
              else
                tempLD.end = tempLD.begin + 1;
              lCourse[j].available_total_hours -= 2;
              lCourse[j].ld.push_back(tempLD);
              Lecturer::allCourses[a].ld.push_back(lCourse[j].ld[n]);
              Lecturer::allCourses[a].available_total_hours = lCourse[j].available_total_hours;
              n++;
            }
          }
        }
      }
    }
    else{     //index = 4  -> OOP
      Course lCourse;
      int temp;
      // o index'teki dersi hangi hoca veriyor bul. O hocanın indexini temp'e ata!
      for(int i=0;i<lecturer.size();i++){
        for(int j=0;j<lecturer[i].getCourses().size();j++){
          if(lecturer[i].getCourses()[j].id == index){//index = courseID
            lCourse = lecturer[i].getCourses()[j];
            break;
          }
        }
      }
      //find course in allCourses to check available_total_hours..
      for(a=0;a<Lecturer::allCourses.size();a++){
        if(Lecturer::allCourses[a].id == lCourse.id)
          break;
      }
      int k=0;
      if(Lecturer::allCourses[a].available_total_hours > 0)
        cout<<"Assigned Before!";
      while(Lecturer::allCourses[a].available_total_hours > 0){
        check = 0;
        int R1 = rand() % 5 ; //day
        int R2 = rand() % 7 + 9 ; //begin => end(max 17) can be begin + 2 so begin should be until 15..

        //Compare with previous days..
        for(int i=0;i<Lecturer::allCourses.size();i++){
          for(int l=0; l<Lecturer::allCourses[i].ld.size(); l++){
            if(Lecturer::allCourses[i].ld[l].day == R1 &&
              (Lecturer::allCourses[i].ld[l].begin <= R2 && Lecturer::allCourses[i].ld[l].end > R2)){
                check = 1;
                break;
            }
          }
        }

        //Compare with other course..
        if(!check){
          tempLD.day = R1;
          tempLD.begin = R2;
          if(lCourse.available_total_hours -2 >= 0)
            tempLD.end = tempLD.begin + 2;
          else
            tempLD.end = tempLD.begin + 1;
          lCourse.available_total_hours -= 2;
          lCourse.ld.push_back(tempLD);
          Lecturer::allCourses[a].ld.push_back(lCourse.ld[k]);
          Lecturer::allCourses[a].available_total_hours = lCourse.available_total_hours;
          k++;
        }
      }
    }
  }

  // return 1: o saatte o ders available_total_hours
  // ders yok !
  int Administrator::checkLecture(int classId,int hour){
    int day = hour/8;
    int hourth = (hour%8)+8;
    for(int i=0;i<classroom[classId-1].fR.size();i++){
      if ( (hourth>=classroom[classId-1].fR[i].begin && hourth<classroom[classId-1].fR[i].end) &&
        (classroom[classId-1].fR[i].day == day) )
          return 1;
    }

    return 0;
  }

  void Administrator::arrangeClassroom(){

    for(int i=0;i<Lecturer::allCourses.size();i++){
      for(int j=0;j<Lecturer::allCourses[i].ld.size();j++){
        int c,temp;
        int error ;
        for(c=0;c<classroom.size();c++){ // classroom is changing..
          error = 1;// can record..
          int count = 0;
          for(int d=0;d<classroom[c].fR.size();d++){ // loop for hour of classrooms
            //o saatte dolu muu. ??
            if(classroom[c].fR[d].day == Lecturer::allCourses[i].ld[j].day ){
              if(classroom[c].fR[d].begin > Lecturer::allCourses[i].ld[j].begin){
                if(classroom[c].fR[d].begin - Lecturer::allCourses[i].ld[j].end  <= -1){ // is overlap !!
                  error = 0;
                }
              }
              else{
                if(Lecturer::allCourses[i].ld[j].begin  - classroom[c].fR[d].end <= -1){ // is overlap !!
                  error = 0;
                }
              }
            }
            if(error == 0)
              d=classroom[c].fR.size();  //jump the outside of loop.
            if(error ){
              count ++;
            }
          }
          if(count == classroom[c].fR.size()){
            break;
          }
        }
        if(error){
          FullRoom tempRoom;
          tempRoom.begin =Lecturer::allCourses[i].ld[j].begin;
          tempRoom.end =Lecturer::allCourses[i].ld[j].end;
          tempRoom.day =Lecturer::allCourses[i].ld[j].day;
          tempRoom.CourseID = Lecturer::allCourses[i].id;
          classroom[c].fR.push_back(tempRoom);
          cout<<Lecturer::allCourses[i].name<<" ";
          switch (Lecturer::allCourses[i].ld[j].day) {
            case 0: cout<<"Mon";
            break;
            case 1: cout<<"Thue";
            break;
            case 2: cout<<"Wed";
            break;
            case 3: cout<<"Thur";
            break;
            case 4: cout<<"Fri";
            break;
          }
          cout<<"_"<<Lecturer::allCourses[i].ld[j].begin<<
          "-"<<Lecturer::allCourses[i].ld[j].end<<" -> "<<classroom[c].getName()<<"\t";
        }
      }
      cout<<endl;
    }
 }//end of function

} //end of namespace...
