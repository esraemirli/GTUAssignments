#include "init.h"
ResearchAssistant::ResearchAssistant(){}
ResearchAssistant::ResearchAssistant(int id,string name,string surname,University& uni)
  :AcademicPersonnel(id,name,surname,uni) { }
ResearchAssistant::ResearchAssistant(const ResearchAssistant& _researcher){
  setPid (_researcher.getPid() );
  setName( _researcher.getName() );
  setSurname( _researcher.getSurname() );
  emp = _researcher.emp;
}
ResearchAssistant& ResearchAssistant::operator =(const ResearchAssistant& _researcher){
  setPid (_researcher.getPid() );
  setName( _researcher.getName() );
  setSurname( _researcher.getSurname() );
  emp = _researcher.emp;
  return *this;
}

ResearchAssistant::~ResearchAssistant(){ }
void ResearchAssistant::research(){
  happiness+=3;
  emp->contribution+=4;
}
void ResearchAssistant::readHW() {
  happiness-=3;
  emp->contribution+=2;
}
void ResearchAssistant::employ(){
  if(emp->action == 2)
    this->research();
  else
    this->readHW();
}
