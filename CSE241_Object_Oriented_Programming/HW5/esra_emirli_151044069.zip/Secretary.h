#ifndef _Secretary_H
#define _Secretary_H

#include "AdministrativePersonnel.h"
class Secretary :public AdministrativePersonnel{
public:
  Secretary();
  Secretary(int,std::string,std::string,University&);
  Secretary(const Secretary&); //copy
  Secretary& operator=(const Secretary&); //assignment
  ~Secretary(); //destructor
  void employ();
  void receivePetition();
};


#endif
