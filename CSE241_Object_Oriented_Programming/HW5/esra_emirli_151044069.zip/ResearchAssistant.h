#ifndef _ResearchAssistant_H
#define _ResearchAssistant_H

#include "AcademicPersonnel.h"
class ResearchAssistant :public AcademicPersonnel{
public:
  ResearchAssistant();
  ResearchAssistant(int,std::string,std::string,University&);
  ResearchAssistant(const ResearchAssistant&); //copy
  ResearchAssistant& operator=(const ResearchAssistant&); //assignment
  ~ResearchAssistant();
  void employ();
  void readHW();
  void research();
};


#endif
