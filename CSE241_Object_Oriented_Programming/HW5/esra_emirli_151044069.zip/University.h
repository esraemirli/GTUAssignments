#ifndef _University_H
#define _University_H
#include "Employee.h"
class University {
public:
  University();
  University(std::string);
  University(int);
  University(const University&); //copy
  University& operator=(const University&); //assignment
  ~University();
  void write(const Employee&) const;
  std::string getName() const;
  static int contribution;
  static int action;
private:
  std::string name;
};


#endif
