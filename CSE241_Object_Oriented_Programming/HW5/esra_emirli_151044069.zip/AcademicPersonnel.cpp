#include "init.h"
AcademicPersonnel::AcademicPersonnel(){}
AcademicPersonnel::AcademicPersonnel(int id,string nameValue,string surnameValue,University& uni)
  :Employee(id,nameValue,surnameValue,uni) { }
  //copy contructor
AcademicPersonnel::AcademicPersonnel(const AcademicPersonnel& _academic){
  setPid(_academic.getPid());
  setName( _academic.getName() );
  setSurname( _academic.getSurname() );
  emp = _academic.emp;
}
//assignment operator
AcademicPersonnel& AcademicPersonnel::operator=(const AcademicPersonnel& _academic){
  setPid(_academic.getPid());
  setName( _academic.getName() );
  setSurname( _academic.getSurname() );
  emp = _academic.emp;
  return *this;
}
AcademicPersonnel::~AcademicPersonnel(){ }
void AcademicPersonnel::seeSuccessfulStudent(){
  //5: seminar by AcademicPersonnel.seeSuccessfulStudent happiness:+10 contribution: +0
  happiness+=10;
}
void AcademicPersonnel::makePublish() {
  //6: academicPaper by AcademicPersonnel.makePublish happiness:+2 contribution:+5
  happiness+=2;
  emp->contribution+=5;
}
void AcademicPersonnel::employ(){
  if(emp->action == 4)
    this->seeSuccessfulStudent();
  else
    this->makePublish();
}
