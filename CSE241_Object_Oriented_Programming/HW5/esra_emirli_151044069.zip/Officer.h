#ifndef _Officer_H
#define _Officer_H

#include "AdministrativePersonnel.h"
class Officer :public AdministrativePersonnel{
public:
  Officer();
  Officer(int,std::string,std::string,University&);
  Officer(const Officer&); //copy
  Officer& operator= (const Officer&); //assignment
  ~Officer(); //destructor
  void makeDoc();
  void employ();
};


#endif
