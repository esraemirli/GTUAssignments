#ifndef _Lecturer_H
#define _Lecturer_H

#include "AcademicPersonnel.h"
class Lecturer :public AcademicPersonnel{
public:
  Lecturer();
  Lecturer(int,std::string,std::string,University&);
  Lecturer(const Lecturer&); //copy
  Lecturer& operator =(const Lecturer&); //assignment
  ~Lecturer();
  void employ();
  void giveLesson();
  void giveHW();
};


#endif
