#include "init.h"
Employee::Employee():happiness(0){}
Employee::Employee(int id,string nameValue,string surnameValue,University& uni)
  :pid(id),name(nameValue),surname(surnameValue),happiness(0),emp(&uni){}
Employee::Employee(const Employee& _employee){
  pid = _employee.pid;
  name = _employee.name;
  surname = _employee.surname;
  emp =_employee.emp;
}
Employee& Employee::operator=(const Employee& _employee){ //assignment operator
  pid = _employee.pid;
  name = _employee.name;
  surname = _employee.surname;
  emp =_employee.emp;

  return *this;
}
Employee::~Employee(){ }
void Employee::setPid(int pidValue){
  pid = pidValue;
}
void Employee::setName(string nameValue){
  name = nameValue;
}
void Employee::setSurname(string surnameValue){
  surname = surnameValue;
}
int Employee::getPid() const{ return pid; }
string Employee::getName() const{ return name; }
string Employee::getSurname() const { return surname ;}

void Employee::drinkTea(){
  happiness+=5;
  emp->contribution-=2;
}
void Employee::submitPetition(){
  happiness+=1;
  emp->contribution-=2;
}
void Employee::employ(){
  if(emp->action == 1)
    this->drinkTea();
  else
    this->submitPetition();
}
void Employee::write() const{
  // (Output)> A have slackness. Therefore, A drinks tea. Happiness of A is 5, contribution of uni is -2.
  cout<<name<<" "<<surname<<" have";
  emp->write(*this);
  cout<<"Happiness of "<<name<<" is "<<happiness<<", contribution of uni is "<<emp->contribution<<"."<<endl;;
}
