#ifndef _Employee_H
#define _Employee_H
#include <string>
#include "University.h"
class University;
class Employee{
public:
  Employee();
  Employee(int,std::string,std::string,University&);
  Employee(const Employee& ); //copy
  virtual ~Employee(); // destructor
  Employee& operator=(const Employee&) ; //assignment operator
  void setName(std::string );
  void setSurname(std::string);
  void setPid(int);
  int getPid() const;
  std::string getName() const;
  std::string getSurname() const;
  int happiness;
  void drinkTea();
  void submitPetition();
  virtual void employ();
  void write() const;
  static int action;
  University* emp;
private:
  int pid;
  std::string name;
  std::string surname;
};


#endif
