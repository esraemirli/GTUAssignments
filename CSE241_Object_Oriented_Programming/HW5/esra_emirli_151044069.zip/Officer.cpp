#include "init.h"

Officer::Officer(){}
Officer::Officer(int id,string name,string surname,University& uni)
  :AdministrativePersonnel(id,name,surname,uni) { }
Officer::Officer(const Officer& _officer){
  setPid (_officer.getPid() );
  setName( _officer.getName() );
  setSurname( _officer.getSurname() );
  emp = _officer.emp;
}
Officer& Officer::operator =(const Officer& _officer){
  setPid (_officer.getPid() );
  setName( _officer.getName() );
  setSurname( _officer.getSurname() );
  emp = _officer.emp;
  return *this;
}
Officer::~Officer(){ }
void Officer::makeDoc(){
  happiness -=2;
  emp->contribution +=3;
}
void Officer::employ(){
  // Officer has one action..
  this->makeDoc();
}
