#include "init.h"
Lecturer::Lecturer(){}
// Lecturer::Lecturer(int pidValue,string nameValue,string surnameValue)
//   :pid(pidValue),name(nameValue),surname(surnameValue){ }
Lecturer::Lecturer(int id,string nameValue,string surnameValue,University& uni)
  :AcademicPersonnel (id,nameValue,surnameValue,uni) { }
Lecturer::Lecturer(const Lecturer& _lecturer){
  setPid (_lecturer.getPid() );
  setName( _lecturer.getName() );
  setSurname( _lecturer.getSurname() );
  emp = _lecturer.emp;
}
Lecturer& Lecturer::operator =(const Lecturer& _lecturer){
  setPid (_lecturer.getPid() );
  setName( _lecturer.getName() );
  setSurname( _lecturer.getSurname() );
  emp = _lecturer.emp;
  return *this;
}

Lecturer::~Lecturer(){ }
void Lecturer::giveLesson(){
  //4: lesson by Lecturer.giveLesson happiness:+1 contribution: +5
  happiness+=1;
  emp->contribution+=5;
}
void Lecturer::giveHW() {
  //8: HomeworkTime by Lecturer.giveHW happiness:-2 contribution:+1
  happiness-=2;
  emp->contribution+=1;
}
void Lecturer::employ(){
  if(emp->action==3)
    this->giveLesson();
  else
    this->giveHW();
}
