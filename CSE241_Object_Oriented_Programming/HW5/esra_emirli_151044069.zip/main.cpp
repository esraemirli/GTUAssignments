#include "init.h"
string findJob(const char* name,char firstWord);
enum actions { document, slackness, project, lesson,seminar,academicPaper,administration,HomeworkTime,homeworkTimeout,incident,solution };
int main(int argc, char const *argv[]) {
  //read personnellist.txt in vector..
  vector< vector<string> > personnellist;
  string name,surname,department;
  ifstream infile;
  infile.open("personnellist.txt");
  int i=0;
  while(!infile.eof()){
    personnellist.push_back(vector<string>());
    infile >> department >> name >> surname;
    personnellist[i].push_back(department);
    personnellist[i].push_back(name);
    personnellist[i].push_back(surname);
    i++;
  }
  infile.close();
  // All jobs must be at least one., then fill random..
  int count[4]; // 0-lecturer 1-ResearchAssistant 2-Secretary 3-Officer
  vector<int> readed; //Donot enter same personnel
  bool sameIndex;
  for(int i=0;i<4;i++)
    count[i] = 0;

  vector<Employee*> employee;
  srand (time(NULL));
  University uni("GTU");  //All employee work in GTU..
  int id=0;
  while(employee.size()<10){
    sameIndex = false;
    i = rand() % (personnellist.size()-1);
    for(int j=0;j<readed.size();j++){
      if(readed[j]==i){
        sameIndex = true;
        break;
      }
    }
    if(!sameIndex){
      id++;
      readed.push_back(i);
      if(personnellist[i][0] == "Lecturer"){
        if( count[0] == 0 || ( count[1]>0 && count[2]>0 && count[3]>0 ) ){
          employee.push_back( new Lecturer(id, personnellist[i][1],personnellist[i][2],uni) );
          count[0]+=1;
        }
      }
      else if(personnellist[i][0] == "ResearchAssistant"){
        if( count[1] == 0 || ( count[0]>0 && count[2]>0 && count[3]>0 ) ){
          employee.push_back( new ResearchAssistant(id,personnellist[i][1],personnellist[i][2],uni) );
          count[1]+=1;
        }
      }
      else if(personnellist[i][0] == "Officer"){
        if( count[3] == 0 || ( count[1]>0 && count[2]>0 && count[0]>0 ) ){
          employee.push_back( new Officer(id,personnellist[i][1],personnellist[i][2],uni ) );
          count[3]+=1;
        }
      }
      else if(personnellist[i][0] == "Secretary"){
        if( count[2] == 0 || ( count[1]>0 && count[0]>0 && count[3]>0 ) ){
          employee.push_back( new Secretary(id,personnellist[i][1],personnellist[i][2],uni ) );
          count[2]+=1;
        }
      }
    }
  }
  // turn 50 times for employee[index]->action..
  for(i=0;i<50;i++){
    int index = rand() % employee.size();
    uni.action = rand() % 11;
    if(uni.action == document){
      // Search until find the Officer personnel in Employee class.
      while( findJob(typeid(*employee[index]).name(),'O') != "Officer"){
        index = rand() % employee.size();
      }
      employee[index]->employ();
    }
    else if(uni.action == slackness){
      // Select any personnel in Employee class..
      employee[index]->Employee::employ();
    }
    else if(uni.action == project){
      //Search until find the ResearchAssistant personnel in Employee class.
      while( findJob(typeid(*employee[index]).name(),'R') != "ResearchAssistant"){
        index = rand() % employee.size();
      }
      employee[index]->employ();
    }
    else if(uni.action==lesson){
      //Search until find the Lecturer personnel in Employee class.
      while( findJob(typeid(*employee[index]).name(),'L') != "Lecturer"){
        index = rand() % employee.size();
      }
      employee[index]->employ();
    }
    else if(uni.action == HomeworkTime){
      //Search until find the Lecturer personnel in Employee class.
      while( findJob(typeid(*employee[index]).name(),'L') != "Lecturer"){
        index = rand() % employee.size();
      }
      employee[index]->employ();
    }
    else if(uni.action == homeworkTimeout){
      //Search until find the ResearchAssistant personnel in Employee class.
      while( findJob(typeid(*employee[index]).name(),'R') != "ResearchAssistant"){
        index = rand() % employee.size();
      }
      employee[index]->employ();
    }
    else if(uni.action == incident){
      // Search until find the Secretary personnel in Employee class.
      while( findJob(typeid(*employee[index]).name(),'S') != "Secretary"){
        index = rand() % employee.size();
      }
      employee[index]->employ();
    }
    else if(uni.action == solution){
      // Select any personnel in Employee class..
      employee[index]->Employee::employ();
    }
    else if(uni.action == seminar){
      // Search until find the any AcademicPersonnel(Lecturer-ResearchAssistant) personnel in Employee class.
      while( findJob(typeid(*employee[index]).name(),'S') != "Lecturer" && findJob(typeid(*employee[index]).name(),'R') != "ResearchAssistant"){
        index = rand() % employee.size();
      }
      AcademicPersonnel *academic = dynamic_cast< AcademicPersonnel* >( &(*employee[index]) ); // upcast ok here
      academic->AcademicPersonnel::employ();
    }
    else if(uni.action == academicPaper){
      // Search until find the any AcademicPersonnel(Lecturer-ResearchAssistant) personnel in Employee class.
      while( findJob(typeid(*employee[index]).name(),'L')!= "Lecturer" && findJob(typeid(*employee[index]).name(),'R') != "ResearchAssistant"){
        index = rand() % employee.size();
      }
      AcademicPersonnel *academic = dynamic_cast< AcademicPersonnel* >( &(*employee[index]) ); // upcast ok here
      academic->AcademicPersonnel::employ();
    }
    else if(uni.action == administration){
      // Search until find the any AdministrativePersonnel(Secretary-Officer) personnel in Employee class.
      while( findJob(typeid(*employee[index]).name(),'S') != "Secretary" && findJob(typeid(*employee[index]).name(),'O') != "Officer"){
        index = rand() % employee.size();
      }
      AdministrativePersonnel *admin = dynamic_cast< AdministrativePersonnel* >( &(*employee[index]) ); // upcast ok here
      admin->AdministrativePersonnel::employ();
    }
    employee[index]->write();
  }
  // Print last results..
  for(int i=0;i<employee.size();i++)
    cout<<"Happiness of "<<employee[i]->getName()<<" "<<employee[i]->getSurname()<<" is "<<employee[i]->happiness<<"."<<endl;
  cout<<"Contribution of university ("<<uni.getName()<<") is "<<uni.contribution<<"."<<endl;

  for(int i=0;i<employee.size();i++)
    delete employee[i];
  return 0;
}
//typeid function return with id and name, this function separate they and return just name..
string findJob(const char* name,char firstWord){
  int index=0,size=0;
  int i,j;
  for(i=0; name[i]!='\0';i++){
    if(name[i]==firstWord){
      index=i;
    }
  }
  size = i;
  char* temp = new char[size];
  for (j=0,i = index; i < size && name[i] != '\0'; j++,i++)
     temp[j] = name[i];
   temp[j] = '\0';

  string jobName = temp;
  delete [] temp;
  return jobName;
}
