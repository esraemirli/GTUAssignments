#ifndef _AdministrativePersonnel_H
#define _AdministrativePersonnel_H

#include "Employee.h"
class AdministrativePersonnel :public Employee{
public:
  AdministrativePersonnel();
  AdministrativePersonnel(int,std::string,std::string,University&);
  AdministrativePersonnel(const AdministrativePersonnel&); //copy
  virtual ~AdministrativePersonnel();
  AdministrativePersonnel& operator= (const AdministrativePersonnel&); //assignment
  void manageProcess();
  virtual void employ();
};


#endif
