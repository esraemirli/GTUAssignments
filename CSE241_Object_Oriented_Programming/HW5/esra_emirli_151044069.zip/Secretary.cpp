#include "init.h"

Secretary::Secretary(){}
Secretary::Secretary(int id,string name,string surname,University& uni)
  :AdministrativePersonnel(id,name,surname,uni) { }
Secretary::Secretary(const Secretary& _secretary){
  setPid (_secretary.getPid() );
  setName( _secretary.getName() );
  setSurname( _secretary.getSurname() );
  emp = _secretary.emp;

}
Secretary& Secretary::operator =(const Secretary& _secretary){
  setPid (_secretary.getPid() );
  setName( _secretary.getName() );
  setSurname( _secretary.getSurname() );
  emp = _secretary.emp;

  return *this;
}

Secretary::~Secretary(){ }
void Secretary::receivePetition(){
  //10: incident by Secretary.receivePetition happiness:-1 contribution:-1
  happiness-=1;
  emp->contribution-=1;
}
void Secretary::employ(){
  this->receivePetition();
}
