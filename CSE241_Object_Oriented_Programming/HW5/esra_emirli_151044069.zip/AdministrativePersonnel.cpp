#include "init.h"

AdministrativePersonnel::AdministrativePersonnel(){}
AdministrativePersonnel::AdministrativePersonnel(int id,string name,string surname,University& uni)
  :Employee(id,name,surname,uni) { }
AdministrativePersonnel::AdministrativePersonnel(const AdministrativePersonnel& _admin){
  setPid(_admin.getPid());
  setName( _admin.getName() );
  setSurname( _admin.getSurname() );
  emp = _admin.emp;
}
AdministrativePersonnel& AdministrativePersonnel::operator =(const AdministrativePersonnel& _admin){
  setPid(_admin.getPid());
  setName( _admin.getName() );
  setSurname( _admin.getSurname() );
  emp = _admin.emp;
  return *this;
}

AdministrativePersonnel::~AdministrativePersonnel(){ }
void AdministrativePersonnel::manageProcess(){
//  7: administration by AdministrativePersonnel.manageProcess happiness:-1 contribution:+2
  happiness-=1;
  emp->contribution+=2;
}
void AdministrativePersonnel::employ(){
  this->manageProcess();
}
