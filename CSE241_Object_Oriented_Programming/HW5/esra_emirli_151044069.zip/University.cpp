#include "init.h"
int University::contribution ;
int University::action;
University::University(){
  contribution = 0;
}
University::University(const University& _uni){
  name = _uni.name;
}
University& University::operator=(const University& _uni){
  name = _uni.name;
  return *this;
}
University::University(string nameValue){
  name = nameValue;
}
University::University(int value){
  contribution = value;
}
string University::getName() const{
  return name;
}
University::~University(){}
void University::write(const Employee& emp) const{
  //(Output)> A have slackness. Therefore, A drinks tea. Happiness of A is 5, contribution of uni is -2.
  switch (action) {
    case 0: cout<<" document.Therefore, "<<emp.getName()<<" makes document.";
    break;
    case 1: cout<<" slackness.Therefore, "<<emp.getName()<<" drinks tea.";
    break;
    case 2: cout<<" project.Therefore, "<<emp.getName()<<" researches.";
    break;
    case 3: cout<<" lesson.Therefore, "<<emp.getName()<<" gives lesson.";
    break;
    case 4: cout<<" seminar.Therefore, "<<emp.getName()<<" see successful student.";
    break;
    case 5: cout<<" academicPaper.Therefore, "<<emp.getName()<<" makes publish.";
    break;
    case 6: cout<<" administration.Therefore, "<<emp.getName()<<" manages process.";
    break;
    case 7: cout<<" homework time.Therefore, "<<emp.getName()<<" gives hw.";
    break;
    case 8: cout<<" homework time out.Therefore, "<<emp.getName()<<" reads hw.";
    break;
    case 9: cout<<" incident.Therefore, "<<emp.getName()<<" receives petition.";
    break;
    case 10: cout<<" solution.Therefore, "<<emp.getName()<<" submit petition.";
    break;
  }
}
