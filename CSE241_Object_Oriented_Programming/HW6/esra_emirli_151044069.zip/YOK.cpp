#include "init.h"
YOK::YOK(){
  intUni=new University<int>();
  doubleUni=new University<double>();
  complexUni=new University<complex<int> >();
  intUni->setName("Marmara");
  doubleUni->setName("Bogazici");
  complexUni->setName("GTU");
}
YOK::YOK(const YOK& _yok){
  intUni = _yok.intUni;
  doubleUni = _yok.doubleUni;
  complexUni = _yok.complexUni;
} //copy

YOK& YOK::operator= (const YOK& _yok){
  intUni = _yok.intUni;
  doubleUni = _yok.doubleUni;
  complexUni = _yok.complexUni;
  return *this;
} //assignment

YOK::~YOK(){
  delete intUni;
  delete doubleUni;
  delete complexUni;
} //destructor

Employee* YOK::giveJob(string _name,string _surname,int _personnelType){
  Employee* employee;
  if(_personnelType == 0)
     employee = new Lecturer( _name, _surname );
  else if(_personnelType == 1)
    employee = new ResearchAssistant( _name, _surname );
  else if(_personnelType == 2)
    employee = new Secretary( _name, _surname );
  else if(_personnelType == 3)
    employee = new Officer( _name, _surname );

  return employee;
}
Base* YOK::foundUni(int uniType){
  if(uniType == 0)
    return intUni;
  else if(uniType == 1)
    return doubleUni;
  else if(uniType == 2)
    return complexUni;
  else
    return NULL;
}
