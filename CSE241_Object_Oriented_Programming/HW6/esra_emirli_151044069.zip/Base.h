#ifndef _Base_H
#define _Base_H
#include <vector>
#include "Employee.h"

class Base{
public:
  Base();
  ~Base();
  std::string getName() const;
  void setName(std::string);
  std::vector<Employee*>& getEmployee();
  void setEmployee(std::vector<Employee*>);
  virtual int employ(Employee*,int) = 0;
  static int action; // to access contirube function in University class..
private:
  std::vector<Employee*> employee;
  std::string name;
};


#endif
