#include "init.h"

Secretary::Secretary(){}
Secretary::Secretary(string name,string surname)
  :AdministrativePersonnel(name,surname) { }
Secretary::Secretary(const Secretary& _secretary){
  setPid (_secretary.getPid() );
  setName( _secretary.getName() );
  setSurname( _secretary.getSurname() );

}
Secretary& Secretary::operator =(const Secretary& _secretary){
  setPid (_secretary.getPid() );
  setName( _secretary.getName() );
  setSurname( _secretary.getSurname() );

  return *this;
}

Secretary::~Secretary(){ }
void Secretary::receivePetition(){
  //10: incident by Secretary.receivePetition happiness:-1 contribution:-1
  happiness-=1;
}
void Secretary::work(string action){
  this->receivePetition();
}
