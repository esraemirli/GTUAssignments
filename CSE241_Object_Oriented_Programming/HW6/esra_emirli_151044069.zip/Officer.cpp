#include "init.h"

Officer::Officer(){}
Officer::Officer(string name,string surname)
  :AdministrativePersonnel(name,surname) { }
Officer::Officer(const Officer& _officer){
  setPid (_officer.getPid() );
  setName( _officer.getName() );
  setSurname( _officer.getSurname() );
}
Officer& Officer::operator =(const Officer& _officer){
  setPid (_officer.getPid() );
  setName( _officer.getName() );
  setSurname( _officer.getSurname() );
  return *this;
}
Officer::~Officer(){ }
void Officer::makeDoc(){
  happiness -=2;
}
void Officer::work(string action){
  // Officer has one action..
  this->makeDoc();
}
