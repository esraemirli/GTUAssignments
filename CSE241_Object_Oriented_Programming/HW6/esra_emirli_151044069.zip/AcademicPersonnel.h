#ifndef _AcademicPersonnel_H
#define _AcademicPersonnel_H

#include "Employee.h"
class AcademicPersonnel: public Employee{
public:
  AcademicPersonnel();
  AcademicPersonnel(std::string,std::string);
  AcademicPersonnel(const AcademicPersonnel&); //copy
  virtual ~AcademicPersonnel(); //destructor
  AcademicPersonnel& operator=(const AcademicPersonnel&); //assignment operator
  void seeSuccessfulStudent();
  void makePublish();
  virtual void work(std::string);
};


#endif
