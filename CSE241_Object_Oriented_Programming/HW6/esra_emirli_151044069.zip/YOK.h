#ifndef _YOK_H
#define _YOK_H
#include <string>
#include <complex>
#include "Employee.h"
#include "Base.h"
#include "University.h"
class YOK {
public:
  YOK();
  YOK(const YOK&); //copy
  YOK& operator= (const YOK&); //assignment
  ~YOK(); //destructor

  Base* foundUni(int); //+foundUni(UniType):University is a Base..
  Employee* giveJob(std::string,std::string,int); //+giveJob(name,surname,empType):Employee

  University<int> *intUni;
  University<double> *doubleUni;
  University<std::complex<int> > *complexUni;
};


#endif
