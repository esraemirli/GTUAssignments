#include "init.h"
int Base::action =0;
Base::Base(){ }
string Base::getName() const{
  return name;
}
void Base::setName(string _name){
  name=_name;
}
Base::~Base(){
  for(int i=0;i<employee.size();i++)
    delete employee[i];
}
vector<Employee*>& Base::getEmployee(){
  return employee;
}
void Base::setEmployee(vector<Employee*> _employee){
  employee.erase(employee.begin(),employee.end());
  for(int i=0;i<_employee.size();i++)
    employee[i] = _employee[i];
}
