#ifndef _University_H
#define _University_H
#include <vector>
#include "Employee.h"

template < class T >
class University : public Base{
public:
  University();
  University(std::string,T);
  University(std::string);
  University(T);
  University(const University<T>&); //copy
  ~University();

  University<T>& operator=(const Base&); //assignment
  const University<T>& operator+( const University<T>&) const;
  const University<T>& operator-( const University<T>&) const;
  bool operator==( const University<T>&) const;
  bool operator!=( const University<T>&) const;
  University<T>& operator++(); //Prefix version
  University<T>& operator++(int); //Postfix version
  University<T>& operator--(); //Prefix version
  University<T>& operator--(int); //Postfix version
  void write(Employee* _employee) const;

  void contribute(T); // ?????????

  void setContribution(T);
  T getContribution() const;
  int employ(Employee*,int); // return value means successful or not..
  int count[4];
private:
  static T contribution;
};

#endif
