#include "init.h"

AdministrativePersonnel::AdministrativePersonnel(){}
AdministrativePersonnel::AdministrativePersonnel(string name,string surname)
  :Employee(name,surname) { }
AdministrativePersonnel::AdministrativePersonnel(const AdministrativePersonnel& _admin){
  setPid(_admin.getPid());
  setName( _admin.getName() );
  setSurname( _admin.getSurname() );
}
AdministrativePersonnel& AdministrativePersonnel::operator =(const AdministrativePersonnel& _admin){
  setPid(_admin.getPid());
  setName( _admin.getName() );
  setSurname( _admin.getSurname() );
  return *this;
}

AdministrativePersonnel::~AdministrativePersonnel(){ }
void AdministrativePersonnel::manageProcess(){
//  7: administration by AdministrativePersonnel.manageProcess happiness:-1 contribution:+2
  happiness-=1;
}
void AdministrativePersonnel::work(string action){
  this->manageProcess();
}
