#include "YOK.h"
#include "University.h"
#include "Employee.h"
#include "AcademicPersonnel.h"
#include "AdministrativePersonnel.h"
#include "Lecturer.h"
#include "ResearchAssistant.h"
#include "Secretary.h"
#include "Officer.h"
#include "Base.h"

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <sstream>
#include <ctime>
#include <fstream>
#include <typeinfo>
#include <stdexcept>
#include <complex>
using namespace std;
