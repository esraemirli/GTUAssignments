#include "init.h"
AcademicPersonnel::AcademicPersonnel(){}
AcademicPersonnel::AcademicPersonnel(string nameValue,string surnameValue)
  :Employee(nameValue,surnameValue) { }
  //copy contructor
AcademicPersonnel::AcademicPersonnel(const AcademicPersonnel& _academic){
  setPid(_academic.getPid());
  setName( _academic.getName() );
  setSurname( _academic.getSurname() );
}
//assignment operator
AcademicPersonnel& AcademicPersonnel::operator=(const AcademicPersonnel& _academic){
  setPid(_academic.getPid());
  setName( _academic.getName() );
  setSurname( _academic.getSurname() );
  return *this;
}
AcademicPersonnel::~AcademicPersonnel(){ }
void AcademicPersonnel::seeSuccessfulStudent(){
  //5: seminar by AcademicPersonnel.seeSuccessfulStudent happiness:+10 contribution: +0
  happiness+=10;
}
void AcademicPersonnel::makePublish() {
  //6: academicPaper by AcademicPersonnel.makePublish happiness:+2 contribution:+5
  happiness+=2;
}
void AcademicPersonnel::work(string action){
  if(action == "seminar")
    seeSuccessfulStudent();
  else
    makePublish();
}
