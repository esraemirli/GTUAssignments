#ifndef _Lecturer_H
#define _Lecturer_H

#include "AcademicPersonnel.h"
class Lecturer :public AcademicPersonnel{
public:
  Lecturer();
  Lecturer(std::string,std::string);
  Lecturer(const Lecturer&); //copy
  Lecturer& operator=(const Lecturer&);   //assignment
  ~Lecturer();
  void work(std::string);
  void giveLesson();
  void giveHW();
};


#endif
