#include "init.h"
string findJob(const char* name,char firstWord);
enum actions { document, slackness, project, lesson,seminar,academicPaper,administration,HomeworkTime,homeworkTimeout,incident,solution };
enum personnelTypes { Lecturer, ResearchAssistant, Secretary, Officer};
enum UniTypes { linguistic, research,  technical };

int main(int argc, char const *argv[]) {
  //read personnellist.txt in vector..
  vector< vector<string> > personnellist;
  string name,surname;
  ifstream infile;
  infile.open("personnellist.txt");
  int i=0;
  while(!infile.eof()){
    personnellist.push_back(vector<string>());
    infile >> name >> surname;
    personnellist[i].push_back(name);
    personnellist[i].push_back(surname);
    i++;
  }
  infile.close();
  personnellist.erase(personnellist.end()-1); //last personnel readed two times so I deleted last one..
  // This can change acording to ide I am not sure..

  YOK yok;
  Base* base;

  srand (time(NULL));
  int id=0,uniType,personnelType;
  while(!personnellist.empty()){
    i = rand() % personnellist.size();  // select personel
    uniType = rand() % 3; // select university type
    personnelType = rand() % 4; // select personnel type
    base = yok.foundUni(uniType); // find university using with type..
    Employee* tempEmployee;
    tempEmployee = yok.giveJob(personnellist[i][0], personnellist[i][1], personnelType);

    if(base->employ(tempEmployee,personnelType)) // If return value is 1, record is successful..
      personnellist.erase(personnellist.begin()+i); // delete this personnel..
  }

  srand (time(NULL));
  // turn 50 times for employee[index]->action..
  for(i=0;i<50;i++){
    int uniType = rand() % 3; // which university type..
    base = yok.foundUni(uniType); // found this type is mean which university
    int index = rand() % base->getEmployee().size(); // find index for employee
    base->action = rand() % 11; // which action ?

    if(base->action == document){
      // Search until find the Officer personnel in Employee class.
      while( findJob(typeid(* base->getEmployee()[index]).name(),'O') != "Officer"){
        index = rand() %  base->getEmployee().size();
      }
      base->getEmployee()[index]->work("document");
    }
    else if(base->action == slackness){
      // Select any personnel in Employee class..
      base->getEmployee()[index]->Employee::work("slackness");
    }
    else if(base->action == project){
      //Search until find the ResearchAssistant personnel in Employee class.
      while( findJob(typeid(*base->getEmployee()[index]).name(),'R') != "ResearchAssistant"){
        index = rand() % base->getEmployee().size();
      }
      base->getEmployee()[index]->work("project");
    }
    else if(base->action==lesson){
      //Search until find the Lecturer personnel in Employee class.
      while( findJob(typeid(* base->getEmployee()[index]).name(),'L') != "Lecturer"){
        index = rand() % base->getEmployee().size();
      }
      base->getEmployee()[index]->work("lesson");
    }
    else if(base->action == HomeworkTime){
      //Search until find the Lecturer personnel in Employee class.
      while( findJob(typeid(* base->getEmployee()[index]).name(),'L') != "Lecturer"){
        index = rand() % base->getEmployee().size();
      }
      base->getEmployee()[index]->work("HomeworkTime");
    }
    else if(base->action == homeworkTimeout){
      //Search until find the ResearchAssistant personnel in Employee class.
      while( findJob(typeid(*base->getEmployee()[index]).name(),'R') != "ResearchAssistant"){
        index = rand() % base->getEmployee().size();
      }
      base->getEmployee()[index]->work("homeworkTimeout");
    }
    else if(base->action == incident){
      // Search until find the Secretary personnel in Employee class.
      while( findJob(typeid(*base->getEmployee()[index]).name(),'S') != "Secretary"){
        index = rand() % base->getEmployee().size();
      }
      base->getEmployee()[index]->work("incident");
    }
    else if(base->action == solution){
      // Select any personnel in Employee class..
      base->getEmployee()[index]->Employee::work("solution");
    }
    else if(base->action == seminar){
      // Search until find the any AcademicPersonnel(Lecturer-ResearchAssistant) personnel in Employee class.
      while( findJob(typeid(*base->getEmployee()[index]).name(),'S') != "Lecturer" &&
        findJob(typeid(*base->getEmployee()[index]).name(),'R') != "ResearchAssistant"){
        index = rand() % base->getEmployee().size();
      }
      AcademicPersonnel *academic = dynamic_cast< AcademicPersonnel* >( &(*base->getEmployee()[index]) ); // upcast ok here
      academic->AcademicPersonnel::work("seminar");
    }
    else if(base->action == academicPaper){
      // Search until find the any AcademicPersonnel(Lecturer-ResearchAssistant) personnel in Employee class.
      while( findJob(typeid(*base->getEmployee()[index]).name(),'L')!= "Lecturer" &&
        findJob(typeid(*base->getEmployee()[index]).name(),'R') != "ResearchAssistant"){
        index = rand() % base->getEmployee().size();
      }
      AcademicPersonnel *academic = dynamic_cast< AcademicPersonnel* >( &(*base->getEmployee()[index]) ); // upcast ok here
      academic->AcademicPersonnel::work("academicPaper");
    }
    else if(base->action == administration){
      // Search until find the any AdministrativePersonnel(Secretary-Officer) personnel in Employee class.
      while( findJob(typeid(*base->getEmployee()[index]).name(),'S') != "Secretary" &&
        findJob(typeid(*base->getEmployee()[index]).name(),'O') != "Officer"){
        index = rand() % base->getEmployee().size();
      }
      AdministrativePersonnel *admin = dynamic_cast< AdministrativePersonnel* >( &(*base->getEmployee()[index]) ); // upcast ok here
      admin->AdministrativePersonnel::work("administration");
    }
    if(uniType == 0){
      University<int> *d = dynamic_cast<University<int> *>(base);
      d->contribute(base->action);
      d->write(base->getEmployee()[index]);
    }else if(uniType == 1){
      University<double> *d = dynamic_cast<University<double> *>(base);
      d->contribute(base->action);
      d->write(base->getEmployee()[index]);
    }else if(uniType == 2){
      University<complex<int> > *d = dynamic_cast<University<complex<int> > *>(base);
      d->contribute(base->action);
      d->write(base->getEmployee()[index]);
    }
  }

  // Happiness of all employees in Maramara(intUni)
  cout<<"MARMARA (Linguistic) EMPLOYEE"<<endl;
  base = yok.foundUni(0);
  for(int i=0;i<base->getEmployee().size();i++){
    cout<<"Happiness of "<<base->getEmployee()[i]->getName()<<" "<<
      base->getEmployee()[i]->getSurname()<<" is "<<base->getEmployee()[i]->happiness<<endl;
  }
  University<int> *integer = dynamic_cast<University<int> *>(base);
  cout<<"Contribution of university is " <<integer->getContribution() <<endl;

  // Happiness of all employees in Boğaziçi(doubleUni)
  cout<<"BOGAZICI (Research) EMPLOYEE"<<endl;
  base = yok.foundUni(1);
  for(int i=0;i<base->getEmployee().size();i++){
    cout<<"Happiness of "<<base->getEmployee()[i]->getName()<<" "<<
      base->getEmployee()[i]->getSurname()<<" is "<<base->getEmployee()[i]->happiness<<endl;
  }
  University<double> *d = dynamic_cast<University<double> *>(base);
  cout<<"Contribution of university is " <<d->getContribution()<<endl;

  // Happiness of all employees in GTU (complexUni)
  cout<<"GTU (Technical) EMPLOYEE"<<endl;
  base = yok.foundUni(2);
  for(int i=0;i<base->getEmployee().size();i++){
    cout<<"Happiness of "<<base->getEmployee()[i]->getName()<<" "<<
      base->getEmployee()[i]->getSurname()<<" is "<<base->getEmployee()[i]->happiness<<endl;
  }
  University<complex<int> > *c = dynamic_cast<University<complex<int> > *>(base);
  cout<<"Contribution of university is " << c->getContribution()<<endl;

  return 0;
}

//typeid function return with id and name, this function separate they and return just name..
string findJob(const char* name,char firstWord){
  int index=0,size=0;
  int i,j;
  for(i=0; name[i]!='\0';i++){
    if(name[i]==firstWord){
      index=i;
    }
  }
  size = i;
  char* temp = new char[size];
  for (j=0,i = index; i < size && name[i] != '\0'; j++,i++)
     temp[j] = name[i];
   temp[j] = '\0';

  string jobName = temp;
  delete [] temp;
  return jobName;
}
