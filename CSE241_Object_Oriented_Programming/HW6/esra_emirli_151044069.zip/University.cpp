#include "init.h"
template<class T>
T University<T>::contribution;

template<class T>
University<T>::University(){
  for(int i=0;i<4;i++)
    count[i] = 0;
  contribution = 0.0;
}

template<class T>
University<T>::University(string nameValue){
  setName(nameValue);
}

template<class T>
University<T>::University(string nameValue,T cont){
  setName(nameValue);
  contribution = cont;
}

template<class T>
University<T>::University(T value){
  contribution = value;
}

template<class T>
University<T>::University(const University<T>& _uni){
  setName(_uni.getName());
  contribution = _uni.contribution;
}

template<class T>
University<T>::~University(){ }

template<class T>
University<T>& University<T>::operator=(const Base& _uni){
  if(this!=&_uni)
    *this = _uni;
  return *this;
}

template<class T>
const University<T>& University<T>::operator +( const University<T>& other) const{
  contribution += other.contribution;
  return *this;
}

template<class T>
const University<T>& University<T>::operator -( const University<T>& other) const{
  contribution -= other.contribution;
  return *this;
}

template<class T>
bool University<T>::operator ==( const University<T>& other) const{
  return ( (getName() == other.getName() ) && (contribution == other.contribution) );
}

template<class T>
bool University<T>::operator !=( const University<T>& other) const{
  return !(*this == other);
}

template<class T>//Prefix version
University<T>& University<T>:: operator++( ){
  contribution+=1;
  return *this;
}

template<class T>//Postfix version
University<T>& University<T>:: operator++(int ignoreMe){
  contribution+=1;
  return *this;
}

template<class T> //Prefix version
University<T>& University<T>:: operator--( ){
  contribution-=1;
  return *this;
}

template<class T>//Postfix version
University<T>& University<T>:: operator--(int ignoreMe){
  contribution-=1;
  return *this;
}
template<class T>
void University<T>::contribute(T value){
  // I have no idea this function what should do, so I used for change contribution.
  switch (action) {
    case 0: contribution+=3;
    break;
    case 1: contribution-=2;
    break;
    case 2: contribution+=4;
    break;
    case 3: contribution+=5;
    break;
    case 4: contribution+=0;
    break;
    case 5: contribution+=5;
    break;
    case 6: contribution+=2;
    break;
    case 7: contribution+=1;
    break;
    case 8: contribution+=2;
    break;
    case 9: contribution-=1;
    break;
    case 10: contribution-=2;
    break;
  }
}
// All jobs must be at least one, then fill random..
template<class T>
int University<T>::employ(Employee* _employee,int _personnelType){
  int check = 0;

  if( getEmployee().size() == 10 ){
    check = 0;
  }
  else if( _personnelType == 0 ){ //Lecturer
    if( count[0] == 0 || ( count[1]>0 && count[2]>0 && count[3]>0 ) ){
      getEmployee().push_back(_employee);
      count[0]+=1;
      check = 1;
    }
  }
  else if( _personnelType == 1 ){ //ResearchAssistant
    if( count[1] == 0 || ( count[0]>0 && count[2]>0 && count[3]>0 ) ){
      getEmployee().push_back(_employee);
      count[1]+=1;
      check = 1;
    }
  }
  else if( _personnelType == 3 ){ //Officer
    if( count[3] == 0 || ( count[1]>0 && count[2]>0 && count[0]>0 ) ){
      getEmployee().push_back(_employee);
      count[3]+=1;
      check = 1;
    }
  }
  else if( _personnelType == 2 ){  //Secretary
    if( count[2] == 0 || ( count[1]>0 && count[0]>0 && count[3]>0 ) ){
      getEmployee().push_back(_employee);
      count[2]+=1;
      check = 1;
    }
  }
  // write this output... this print just enroll is success..
  if(check){
    // output)> GTU requests Lecturer
    // (output)>YOK give job to Ahmet Dizdar as lecturer.
    // (output)> GTU employs Ahmet Dizdar as Lecturer.
    string job;
    switch (_personnelType) {
      case 0: job="Lecturer";
      break;
      case 1: job="ResearchAssistant";
      break;
      case 2: job="Secretary";
      break;
      case 3: job="Officer";
      break;
    }
    cout<<getName()<<" requests "<<job<<endl;
    cout<<"YOK give job to "<<_employee->getName()<<" "<<_employee->getSurname()<<" as "<<job<<endl;
    cout<<getName()<<" employs "<<_employee->getName()<<" "<<_employee->getSurname()<<" as "<<job<<endl;
  }
  return check;
}

template<class T>
void University<T>::setContribution(T _cont){
  contribution = _cont;
}

template<class T>
T University<T>::getContribution() const{
  return contribution;
}


template<class T>
void University<T>::write(Employee* _employee) const{
  //(Output)> A have slackness. Therefore, A drinks tea. Happiness of A is 5, contribution of uni is -2.
  switch (action) {
      case 0: cout<< _employee->getName()<<" "<< _employee->getSurname()<<"have document.Therefore, "
        << _employee->getName()<<" makes document.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
        ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
      case 1: cout<< _employee->getName()<<" "<< _employee->getSurname()<<" have slackness.Therefore, "
        << _employee->getName()<<" drinks tea.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
        ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
      case 2: cout<< _employee->getName()<<" "<< _employee->getSurname()<<" have project.Therefore, "
      << _employee->getName()<<" researches.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
      ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
      case 3: cout<< _employee->getName()<<" "<< _employee->getSurname()<<" have lesson.Therefore, "
      << _employee->getName()<<" gives lesson.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
      ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
      case 4: cout<< _employee->getName()<<" "<< _employee->getSurname()<<" have seminar.Therefore, "
      << _employee->getName()<<" see successful student.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
      ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
      case 5: cout<< _employee->getName()<<" "<< _employee->getSurname()<<" have academicPaper.Therefore, "
      << _employee->getName()<<" makes publish.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
      ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
      case 6: cout<< _employee->getName()<<" "<< _employee->getSurname()<<" have administration.Therefore, "
      << _employee->getName()<<" manages process.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
      ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
      case 7: cout<< _employee->getName()<<" "<< _employee->getSurname()<<" have homework time.Therefore, "
      << _employee->getName()<<" gives hw.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
      ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
      case 8: cout<< _employee->getName()<<" "<< _employee->getSurname()<<" have homework time out.Therefore, "
      << _employee->getName()<<" reads hw.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
      ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
      case 9: cout<< _employee->getName()<<" "<< _employee->getSurname()<<" have incident.Therefore, "
      << _employee->getName()<<" receives petition.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
      ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
      case 10: cout<< _employee->getName()<<" "<< _employee->getSurname()<<" have solution.Therefore, "
      << _employee->getName()<<" submit petition.Happiness of "<<_employee->getName()<<" is "<< _employee->happiness<<
      ", contribution of uni("<<getName()<<") is "<< contribution<<endl;
      break;
    }
}
template class University<int>;
template class University<double>;
template class University<complex<int> >;
