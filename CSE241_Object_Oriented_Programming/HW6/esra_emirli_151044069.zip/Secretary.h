#ifndef _Secretary_H
#define _Secretary_H

#include "AdministrativePersonnel.h"
class Secretary :public AdministrativePersonnel{
public:
  Secretary();
  Secretary(std::string,std::string);
  Secretary(const Secretary&); //copy
  Secretary& operator=(const Secretary&); //assignment
  ~Secretary(); //destructor
  void work(std::string);
  void receivePetition();
};


#endif
