#include "init.h"
Employee::Employee():happiness(0){}
Employee::Employee(string nameValue,string surnameValue)
  :name(nameValue),surname(surnameValue),happiness(0){}
Employee::Employee(const Employee& _employee){
  pid = _employee.pid;
  name = _employee.name;
  surname = _employee.surname;
}
Employee& Employee::operator=(const Employee& _employee){ //assignment operator
  pid = _employee.pid;
  name = _employee.name;
  surname = _employee.surname;

  return *this;
}
Employee::~Employee(){}
void Employee::setPid(int pidValue){
  pid = pidValue;
}
void Employee::setName(string nameValue){
  name = nameValue;
}
void Employee::setSurname(string surnameValue){
  surname = surnameValue;
}
int Employee::getPid() const{ return pid; }
string Employee::getName() const{ return name; }
string Employee::getSurname() const { return surname; }

void Employee::drinkTea(){
  happiness+=5;
}
void Employee::submitPetition(){
  happiness+=1;
}
void Employee::work(string action){
  if(action == "slackness")
    this->drinkTea();
  else
    this->submitPetition();
}
