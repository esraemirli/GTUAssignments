#include "init.h"
ResearchAssistant::ResearchAssistant(){}
ResearchAssistant::ResearchAssistant(string name,string surname)
  :AcademicPersonnel(name,surname) { }
ResearchAssistant::ResearchAssistant(const ResearchAssistant& _researcher){
  setPid (_researcher.getPid() );
  setName( _researcher.getName() );
  setSurname( _researcher.getSurname() );
}
ResearchAssistant& ResearchAssistant::operator =(const ResearchAssistant& _researcher){
  setPid (_researcher.getPid() );
  setName( _researcher.getName() );
  setSurname( _researcher.getSurname() );
  return *this;
}

ResearchAssistant::~ResearchAssistant(){ }
void ResearchAssistant::research(){
  happiness+=3;
}
void ResearchAssistant::readHW() {
  happiness-=3;
}
void ResearchAssistant::work(string action){
  if(action == "project")
    this->research();
  else
    this->readHW();
}
