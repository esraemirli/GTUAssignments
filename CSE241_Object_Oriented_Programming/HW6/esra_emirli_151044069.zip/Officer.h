#ifndef _Officer_H
#define _Officer_H

#include "AdministrativePersonnel.h"
class Officer :public AdministrativePersonnel{
public:
  Officer();
  Officer(std::string,std::string);
  Officer(const Officer&); //copy
  Officer& operator= (const Officer&); //assignment
  ~Officer(); //destructor
  void makeDoc();
  void work(std::string);
};


#endif
