#include "init.h"
Lecturer::Lecturer(){}
// Lecturer::Lecturer(int pidValue,string nameValue,string surnameValue)
//   :pid(pidValue),name(nameValue),surname(surnameValue){ }
Lecturer::Lecturer(string nameValue,string surnameValue)
  :AcademicPersonnel (nameValue,surnameValue) { }
Lecturer::Lecturer(const Lecturer& _lecturer){
  setPid (_lecturer.getPid() );
  setName( _lecturer.getName() );
  setSurname( _lecturer.getSurname() );
}
Lecturer& Lecturer::operator=(const Lecturer& _lecturer){
  setPid (_lecturer.getPid() );
  setName( _lecturer.getName() );
  setSurname( _lecturer.getSurname() );
  return *this;
}

Lecturer::~Lecturer(){ }
void Lecturer::giveLesson(){
  //4: lesson by Lecturer.giveLesson happiness:+1 contribution: +5
  happiness+=1;
}
void Lecturer::giveHW() {
  //8: HomeworkTime by Lecturer.giveHW happiness:-2 contribution:+1
  happiness-=2;
}
void Lecturer::work(string action){
  if(action=="lesson")
    this->giveLesson();
  else
    this->giveHW();
}
