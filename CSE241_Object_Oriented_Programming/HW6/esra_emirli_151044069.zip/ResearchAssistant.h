#ifndef _ResearchAssistant_H
#define _ResearchAssistant_H

#include "AcademicPersonnel.h"
class ResearchAssistant :public AcademicPersonnel{
public:
  ResearchAssistant();
  ResearchAssistant(std::string,std::string);
  ResearchAssistant(const ResearchAssistant&); //copy
  ResearchAssistant& operator=(const ResearchAssistant&); //assignment
  ~ResearchAssistant();
  void work(std::string);
  void readHW();
  void research();
};


#endif
