flight(edirne,edremit,914.67).
flight(edremit,edirne,914.67).
flight(edremit,erzincan,736.34).
flight(erzincan,edremit,736.34).
flight(istanbul,izmir,328.80).
flight(istanbul,antalya,482.75).
flight(istanbul,gaziantep,847.42).
flight(istanbul,ankara,351.50).
flight(istanbul,van,1262.37).
flight(istanbul,rize,967.79).
flight(izmir,istanbul,328.80).
flight(izmir,ısparta,308.55).
flight(ısparta,izmir,308.55).
flight(ısparta,burdur,24.60).
flight(burdur,ısparta,24.60).
flight(antalya,istanbul,482.75).
flight(antalya,konya,192.28).
flight(antalya,gaziantep,592.33).
flight(konya,antalya,192.28).
flight(konya,ankara,227.34).
flight(gaziantep,antalya,592.33).
flight(gaziantep,istanbul,847.42).
flight(ankara,istanbul,351.50).
flight(ankara,konya,227.34).
flight(ankara,van,920.31).
flight(van,istanbul,1262.37).
flight(van,ankara,920.31).
flight(van,rize,373.01).
flight(rize,istanbul,967.79).
flight(rize,van,373.01).

% rota base case
sroute(X, Y, D) :- 
	sroute(X, Y, D, [], X).
% sroute
sroute(X, Y, D, P, L) :-
	\+member(X, P),
	flight(X, Z, D1),
	not(Z = L),
	sroute(Z, Y, D2, [X|P], X),
        write(P),nl,
	not(Y = L),
	not(X = Y),
	D is D1 + D2.	
% sroute

sroute(X, Y, D, _, _) :- 
	flight(X, Y, D).

